﻿namespace QuizManagementSystem_ADBMS_Project.Forms
{
    partial class QuestionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.lbl_teacher = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtQuizNumber = new System.Windows.Forms.TextBox();
            this.txtCourseCode = new System.Windows.Forms.TextBox();
            this.rbtnEditQuestion = new System.Windows.Forms.RadioButton();
            this.rbtnAddNewQuestion = new System.Windows.Forms.RadioButton();
            this.rbtnDeleteQuestion = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(526, 403);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(92, 35);
            this.btnBack.TabIndex = 38;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // lbl_teacher
            // 
            this.lbl_teacher.AutoSize = true;
            this.lbl_teacher.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_teacher.Location = new System.Drawing.Point(279, 139);
            this.lbl_teacher.Name = "lbl_teacher";
            this.lbl_teacher.Size = new System.Drawing.Size(266, 23);
            this.lbl_teacher.TabIndex = 37;
            this.lbl_teacher.Text = "QUESTION MANAGEMENT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(192, 251);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 19);
            this.label3.TabIndex = 36;
            this.label3.Text = "Enter Quiz Number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(192, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 19);
            this.label2.TabIndex = 35;
            this.label2.Text = "Enter CourseCode:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(208, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 31);
            this.label1.TabIndex = 34;
            this.label1.Text = "QUIZ MANAGEMENT SYSTEM";
            // 
            // txtQuizNumber
            // 
            this.txtQuizNumber.Location = new System.Drawing.Point(344, 251);
            this.txtQuizNumber.Name = "txtQuizNumber";
            this.txtQuizNumber.Size = new System.Drawing.Size(274, 22);
            this.txtQuizNumber.TabIndex = 32;
            // 
            // txtCourseCode
            // 
            this.txtCourseCode.Location = new System.Drawing.Point(344, 206);
            this.txtCourseCode.Name = "txtCourseCode";
            this.txtCourseCode.Size = new System.Drawing.Size(274, 22);
            this.txtCourseCode.TabIndex = 31;
            // 
            // rbtnEditQuestion
            // 
            this.rbtnEditQuestion.AutoSize = true;
            this.rbtnEditQuestion.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnEditQuestion.Location = new System.Drawing.Point(163, 337);
            this.rbtnEditQuestion.Name = "rbtnEditQuestion";
            this.rbtnEditQuestion.Size = new System.Drawing.Size(133, 23);
            this.rbtnEditQuestion.TabIndex = 39;
            this.rbtnEditQuestion.TabStop = true;
            this.rbtnEditQuestion.Text = "Edit Question";
            this.rbtnEditQuestion.UseVisualStyleBackColor = true;
            // 
            // rbtnAddNewQuestion
            // 
            this.rbtnAddNewQuestion.AutoSize = true;
            this.rbtnAddNewQuestion.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAddNewQuestion.Location = new System.Drawing.Point(344, 337);
            this.rbtnAddNewQuestion.Name = "rbtnAddNewQuestion";
            this.rbtnAddNewQuestion.Size = new System.Drawing.Size(167, 23);
            this.rbtnAddNewQuestion.TabIndex = 40;
            this.rbtnAddNewQuestion.TabStop = true;
            this.rbtnAddNewQuestion.Text = "Add New Question";
            this.rbtnAddNewQuestion.UseVisualStyleBackColor = true;
            // 
            // rbtnDeleteQuestion
            // 
            this.rbtnDeleteQuestion.AutoSize = true;
            this.rbtnDeleteQuestion.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnDeleteQuestion.Location = new System.Drawing.Point(552, 337);
            this.rbtnDeleteQuestion.Name = "rbtnDeleteQuestion";
            this.rbtnDeleteQuestion.Size = new System.Drawing.Size(149, 23);
            this.rbtnDeleteQuestion.TabIndex = 41;
            this.rbtnDeleteQuestion.TabStop = true;
            this.rbtnDeleteQuestion.Text = "Delete Question";
            this.rbtnDeleteQuestion.UseVisualStyleBackColor = true;
            // 
            // QuestionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rbtnDeleteQuestion);
            this.Controls.Add(this.rbtnAddNewQuestion);
            this.Controls.Add(this.rbtnEditQuestion);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lbl_teacher);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtQuizNumber);
            this.Controls.Add(this.txtCourseCode);
            this.Name = "QuestionForm";
            this.Text = "QuestionForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lbl_teacher;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtQuizNumber;
        private System.Windows.Forms.TextBox txtCourseCode;
        private System.Windows.Forms.RadioButton rbtnEditQuestion;
        private System.Windows.Forms.RadioButton rbtnAddNewQuestion;
        private System.Windows.Forms.RadioButton rbtnDeleteQuestion;
    }
}