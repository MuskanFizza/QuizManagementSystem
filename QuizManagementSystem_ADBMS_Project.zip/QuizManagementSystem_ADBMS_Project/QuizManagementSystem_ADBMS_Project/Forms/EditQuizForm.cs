﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class EditQuizForm : Form
    {
        int teacherID;
        public EditQuizForm(int id)
        {
            InitializeComponent();
            teacherID = id;
        }

        private void btnProceed_Click(object sender, EventArgs e)
        {

           // string courseCode = txtCourseCode.Text.Trim();
            string courseCode = cmbCourses.ValueMember.ToString();
            string quizNumber = txtQuizNumber.Text.Trim();

          /*  if (string.IsNullOrEmpty(courseCode) || string.IsNullOrEmpty(quizNumber))
            {
                MessageBox.Show("Please enter both Course Code and Quiz Number.");
                return;
            }*/

            if (rbtnEditQuestion.Checked)
            {
                EditQuestionForm editForm = new EditQuestionForm(teacherID,courseCode, quizNumber);
                editForm.Show();
            }
            else if (rbtnAddNewQuestion.Checked)
            {
                AddNewQuestionForm  addForm = new AddNewQuestionForm(courseCode, quizNumber, teacherID);
                addForm.Show();
            }
            else if (rbtnDeleteQuestion.Checked)
            {
                DeleteQuestionForm deleteForm = new DeleteQuestionForm(courseCode, quizNumber, teacherID);
                deleteForm.Show();
            }
            else if (rbtn_ChangeType.Checked)
            {
                ChangeQuizType deleteForm = new ChangeQuizType(teacherID);
                deleteForm.Show();
            }
            else
            {
                MessageBox.Show("Please select an action.");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            QuizManagement qm = new QuizManagement(teacherID);
            qm.Show();
            this.Close();
        }


        private void LoadTeacherCourses(int teacherID)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("GetTeacherCourses", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TeacherID", teacherID);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);

                cmbCourses.DataSource = dt;
                cmbCourses.DisplayMember = "CourseName";
                cmbCourses.ValueMember = "CourseCode";
            }
        }

        private void EditQuizForm_Load(object sender, EventArgs e)
        {
            LoadTeacherCourses(teacherID);
        }

        private void rbtn_ChangeType_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
