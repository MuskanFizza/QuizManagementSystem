﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class TeacherManagementForm : Form
    {
        public TeacherManagementForm()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminDashboard ad = new AdminDashboard(this);
            ad.Show();
            this.Close();
        }

        private void btnAddTeacher_Click(object sender, EventArgs e)
        {
            AddTeacherForm atf = new AddTeacherForm();
            atf.Show();
            this.Hide();
        }

        private void btnViewTeacher_Click(object sender, EventArgs e)
        {
            ViewTeachersForm vtf = new ViewTeachersForm();
            vtf.Show();
            this.Hide();
        }

        private void btnEditTeacher_Click(object sender, EventArgs e)
        {
            EditTeacherForm etf = new EditTeacherForm();
            etf.Show();
            this.Hide();
        }

        private void btnDelTeacher_Click(object sender, EventArgs e)
        {
            DeleteTeacherFormcs dtf = new DeleteTeacherFormcs();    
            dtf.Show();
            this.Hide();
        }
    }
}
