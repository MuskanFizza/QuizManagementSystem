﻿namespace QuizManagementSystem_ADBMS_Project.Forms
{
    partial class EditQuizForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbtnDeleteQuestion = new System.Windows.Forms.RadioButton();
            this.rbtnAddNewQuestion = new System.Windows.Forms.RadioButton();
            this.rbtnEditQuestion = new System.Windows.Forms.RadioButton();
            this.btnBack = new System.Windows.Forms.Button();
            this.lbl_teacher = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtQuizNumber = new System.Windows.Forms.TextBox();
            this.btnProceed = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbCourses = new System.Windows.Forms.ComboBox();
            this.rbtn_ChangeType = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // rbtnDeleteQuestion
            // 
            this.rbtnDeleteQuestion.AutoSize = true;
            this.rbtnDeleteQuestion.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnDeleteQuestion.Location = new System.Drawing.Point(489, 256);
            this.rbtnDeleteQuestion.Name = "rbtnDeleteQuestion";
            this.rbtnDeleteQuestion.Size = new System.Drawing.Size(149, 23);
            this.rbtnDeleteQuestion.TabIndex = 51;
            this.rbtnDeleteQuestion.TabStop = true;
            this.rbtnDeleteQuestion.Text = "Delete Question";
            this.rbtnDeleteQuestion.UseVisualStyleBackColor = true;
            // 
            // rbtnAddNewQuestion
            // 
            this.rbtnAddNewQuestion.AutoSize = true;
            this.rbtnAddNewQuestion.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAddNewQuestion.Location = new System.Drawing.Point(281, 256);
            this.rbtnAddNewQuestion.Name = "rbtnAddNewQuestion";
            this.rbtnAddNewQuestion.Size = new System.Drawing.Size(167, 23);
            this.rbtnAddNewQuestion.TabIndex = 50;
            this.rbtnAddNewQuestion.TabStop = true;
            this.rbtnAddNewQuestion.Text = "Add New Question";
            this.rbtnAddNewQuestion.UseVisualStyleBackColor = true;
            // 
            // rbtnEditQuestion
            // 
            this.rbtnEditQuestion.AutoSize = true;
            this.rbtnEditQuestion.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnEditQuestion.Location = new System.Drawing.Point(100, 256);
            this.rbtnEditQuestion.Name = "rbtnEditQuestion";
            this.rbtnEditQuestion.Size = new System.Drawing.Size(133, 23);
            this.rbtnEditQuestion.TabIndex = 49;
            this.rbtnEditQuestion.TabStop = true;
            this.rbtnEditQuestion.Text = "Edit Question";
            this.rbtnEditQuestion.UseVisualStyleBackColor = true;
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(278, 379);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(92, 35);
            this.btnBack.TabIndex = 48;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lbl_teacher
            // 
            this.lbl_teacher.AutoSize = true;
            this.lbl_teacher.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_teacher.Location = new System.Drawing.Point(318, 118);
            this.lbl_teacher.Name = "lbl_teacher";
            this.lbl_teacher.Size = new System.Drawing.Size(111, 23);
            this.lbl_teacher.TabIndex = 47;
            this.lbl_teacher.Text = "EDIT QUIZ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(117, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 19);
            this.label3.TabIndex = 46;
            this.label3.Text = "Enter Quiz Number:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(176, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 31);
            this.label1.TabIndex = 44;
            this.label1.Text = "QUIZ MANAGEMENT SYSTEM";
            // 
            // txtQuizNumber
            // 
            this.txtQuizNumber.Location = new System.Drawing.Point(281, 199);
            this.txtQuizNumber.Name = "txtQuizNumber";
            this.txtQuizNumber.Size = new System.Drawing.Size(127, 22);
            this.txtQuizNumber.TabIndex = 43;
            // 
            // btnProceed
            // 
            this.btnProceed.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProceed.Location = new System.Drawing.Point(407, 379);
            this.btnProceed.Name = "btnProceed";
            this.btnProceed.Size = new System.Drawing.Size(92, 35);
            this.btnProceed.TabIndex = 52;
            this.btnProceed.Text = "Proceed";
            this.btnProceed.UseVisualStyleBackColor = true;
            this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(437, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 19);
            this.label4.TabIndex = 54;
            this.label4.Text = "Courses:";
            // 
            // cmbCourses
            // 
            this.cmbCourses.FormattingEnabled = true;
            this.cmbCourses.Items.AddRange(new object[] {
            ""});
            this.cmbCourses.Location = new System.Drawing.Point(513, 197);
            this.cmbCourses.Name = "cmbCourses";
            this.cmbCourses.Size = new System.Drawing.Size(154, 24);
            this.cmbCourses.TabIndex = 53;
            // 
            // rbtn_ChangeType
            // 
            this.rbtn_ChangeType.AutoSize = true;
            this.rbtn_ChangeType.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtn_ChangeType.Location = new System.Drawing.Point(322, 313);
            this.rbtn_ChangeType.Name = "rbtn_ChangeType";
            this.rbtn_ChangeType.Size = new System.Drawing.Size(123, 23);
            this.rbtn_ChangeType.TabIndex = 55;
            this.rbtn_ChangeType.TabStop = true;
            this.rbtn_ChangeType.Text = "Change Type";
            this.rbtn_ChangeType.UseVisualStyleBackColor = true;
            this.rbtn_ChangeType.CheckedChanged += new System.EventHandler(this.rbtn_ChangeType_CheckedChanged);
            // 
            // EditQuizForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rbtn_ChangeType);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbCourses);
            this.Controls.Add(this.btnProceed);
            this.Controls.Add(this.rbtnDeleteQuestion);
            this.Controls.Add(this.rbtnAddNewQuestion);
            this.Controls.Add(this.rbtnEditQuestion);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lbl_teacher);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtQuizNumber);
            this.Name = "EditQuizForm";
            this.Text = "EditQuizForm";
            this.Load += new System.EventHandler(this.EditQuizForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbtnDeleteQuestion;
        private System.Windows.Forms.RadioButton rbtnAddNewQuestion;
        private System.Windows.Forms.RadioButton rbtnEditQuestion;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lbl_teacher;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtQuizNumber;
        private System.Windows.Forms.Button btnProceed;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbCourses;
        private System.Windows.Forms.RadioButton rbtn_ChangeType;
    }
}