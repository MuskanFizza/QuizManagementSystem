﻿namespace QuizManagementSystem_ADBMS_Project.Forms
{
    partial class QuestionManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btbDelStd = new System.Windows.Forms.Button();
            this.btnEditStd = new System.Windows.Forms.Button();
            this.btnViewStds = new System.Windows.Forms.Button();
            this.btnAddStd = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(200, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 31);
            this.label1.TabIndex = 31;
            this.label1.Text = "QUIZ MANAGEMENT SYSTEM";
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(341, 372);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(116, 35);
            this.btnBack.TabIndex = 30;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // btbDelStd
            // 
            this.btbDelStd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btbDelStd.Location = new System.Drawing.Point(428, 278);
            this.btbDelStd.Name = "btbDelStd";
            this.btbDelStd.Size = new System.Drawing.Size(146, 48);
            this.btbDelStd.TabIndex = 29;
            this.btbDelStd.Text = "Delete Questions";
            this.btbDelStd.UseVisualStyleBackColor = true;
            // 
            // btnEditStd
            // 
            this.btnEditStd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditStd.Location = new System.Drawing.Point(225, 278);
            this.btnEditStd.Name = "btnEditStd";
            this.btnEditStd.Size = new System.Drawing.Size(146, 48);
            this.btnEditStd.TabIndex = 28;
            this.btnEditStd.Text = "Edit Questions";
            this.btnEditStd.UseVisualStyleBackColor = true;
            // 
            // btnViewStds
            // 
            this.btnViewStds.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewStds.Location = new System.Drawing.Point(428, 189);
            this.btnViewStds.Name = "btnViewStds";
            this.btnViewStds.Size = new System.Drawing.Size(146, 48);
            this.btnViewStds.TabIndex = 27;
            this.btnViewStds.Text = "View Questions";
            this.btnViewStds.UseVisualStyleBackColor = true;
            // 
            // btnAddStd
            // 
            this.btnAddStd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStd.Location = new System.Drawing.Point(225, 189);
            this.btnAddStd.Name = "btnAddStd";
            this.btnAddStd.Size = new System.Drawing.Size(146, 48);
            this.btnAddStd.TabIndex = 26;
            this.btnAddStd.Text = "Add Question";
            this.btnAddStd.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(267, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(266, 23);
            this.label4.TabIndex = 25;
            this.label4.Text = "QUESTION MANAGEMENT";
            // 
            // QuestionManagementForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btbDelStd);
            this.Controls.Add(this.btnEditStd);
            this.Controls.Add(this.btnViewStds);
            this.Controls.Add(this.btnAddStd);
            this.Controls.Add(this.label4);
            this.Name = "QuestionManagementForm";
            this.Text = "QuestionManagementForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btbDelStd;
        private System.Windows.Forms.Button btnEditStd;
        private System.Windows.Forms.Button btnViewStds;
        private System.Windows.Forms.Button btnAddStd;
        private System.Windows.Forms.Label label4;
    }
}