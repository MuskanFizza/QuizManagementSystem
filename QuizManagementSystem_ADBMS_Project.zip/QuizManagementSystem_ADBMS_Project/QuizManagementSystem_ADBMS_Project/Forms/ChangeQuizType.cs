﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class ChangeQuizType : Form
    {
        int id;
        public ChangeQuizType(int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
           
            if (string.IsNullOrWhiteSpace(txtChangeFrom.Text) ||
                string.IsNullOrWhiteSpace(txtChangeTo.Text))
            {
                MessageBox.Show("Please enter both Source and Target Quiz IDs.");
                return;
            }

            if (!int.TryParse(txtChangeFrom.Text, out int sourceQuizID) ||
                !int.TryParse(txtChangeTo.Text, out int targetQuizID))
            {
                MessageBox.Show("Please enter valid numeric Quiz IDs.");
                return;
            }

            try
            {

                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand("CopyQuizQuestions", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@SourceQuizID", sourceQuizID);
                        cmd.Parameters.AddWithValue("@TargetQuizID", targetQuizID);

                        conn.Open();

                        string message = cmd.ExecuteScalar()?.ToString();

                        MessageBox.Show(message);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            EditQuizForm eqf = new EditQuizForm(id);
            eqf.Show();
            this.Hide();

        }
    }
}