﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class ViewQuizFormTeacher : Form
    {
        private bool isFormLoaded = false;
        int teacherID;
        public ViewQuizFormTeacher(int id)
        {
            InitializeComponent();
            teacherID = id; 
        }

        


        private void LoadTeacherCourses(int teacherID)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("GetTeacherCourses", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TeacherID", teacherID);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);

                cmbCourses.DataSource = dt;
                cmbCourses.DisplayMember = "CourseName";
                cmbCourses.ValueMember = "CourseCode";
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            string searchBy = comboBoxFilter.Text;   // e.g., CourseCode / QuizTitle / QuestionID
            string searchValue = txtSearchValue.Text;

            LoadQuizDetails(searchBy, searchValue);
        }
        private void LoadQuizDetails(string searchBy = null, string searchValue = null)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("GetQuizDetails", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                // 🔥 IMPORTANT
                cmd.Parameters.AddWithValue("@TeacherID", teacherID);

                cmd.Parameters.AddWithValue("@SearchBy",
                    string.IsNullOrEmpty(searchBy) ? (object)DBNull.Value : searchBy);

                cmd.Parameters.AddWithValue("@SearchValue",
                    string.IsNullOrEmpty(searchValue) ? (object)DBNull.Value : searchValue);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                try
                {
                    con.Open();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No quiz details found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        /*private void LoadQuizDetails(string searchBy = null, string searchValue = null)
        {


            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                using (SqlCommand cmd = new SqlCommand("GetQuizDetails", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Parameters
                    cmd.Parameters.AddWithValue("@SearchBy",
                        string.IsNullOrEmpty(searchBy) ? (object)DBNull.Value : searchBy);

                    cmd.Parameters.AddWithValue("@SearchValue",
                        string.IsNullOrEmpty(searchValue) ? (object)DBNull.Value : searchValue);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    try
                    {
                        con.Open();
                        da.Fill(dt);

                        dataGridView1.DataSource = dt;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }*/
        

        private void btnBack_Click(object sender, EventArgs e)
        {
            QuizManagement qm = new QuizManagement(teacherID);
            qm.Show();
            this.Hide();
        }

        private void ViewQuizForm_Load(object sender, EventArgs e)
        {
            LoadTeacherCourses(teacherID);

            isFormLoaded = true;

            if (cmbCourses.Items.Count > 0)
            {
                cmbCourses.SelectedIndex = 0;
            }
        }

        



        private void cmbCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void LoadQuizzesByCourse(string courseCode)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("GetQuizzesByTeacherCourse", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@TeacherID", teacherID);
                cmd.Parameters.AddWithValue("@CourseCode", courseCode);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                try
                {
                    con.Open();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No quizzes found for this course.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void cmbCourses_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (!isFormLoaded) return;

            if (cmbCourses.SelectedValue == null) return;

            string courseCode = cmbCourses.SelectedValue.ToString();

            LoadQuizzesByCourse(courseCode);
        
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
    
    

}
