﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class ViewResultForm : Form
    {
        private Form _parentForm;
        int studentID;

        public ViewResultForm(Form parent, int studentID = 0)
        {
            InitializeComponent();
            _parentForm = parent;
            this.studentID = studentID;
        }


        /* private void LoadData(string filterQuery = "")
         {
             using (SqlConnection con = DatabaseHelper.GetConnection())

             {
                 con.Open();

                 string query = 
                     @"SELECT s.StudentID AS Sid, s.SName AS Sname, c.CourseCode,
                             MAX(CASE WHEN q.QuizNumber = 1 THEN r.TotalMarks END) AS Q1,
                             MAX(CASE WHEN q.QuizNumber = 2 THEN r.TotalMarks END) AS Q2
                         FROM Result r
                         JOIN Student s ON r.StudentID = s.StudentID
                         JOIN Quiz q ON r.QuizID = q.QuizID
                         JOIN Course c ON q.CourseCode = c.CourseCode"
                         + filterQuery + @" GROUP BY s.StudentID, s.SName, c.CourseCode
                             ORDER BY s.StudentID";

                 SqlDataAdapter da = new SqlDataAdapter(query, con);
                 DataTable dt = new DataTable();
                 da.Fill(dt);

                 dataGridView1.DataSource = dt;
             }
         }
         private void ViewResultForm_Load(object sender, EventArgs e)
         {
             LoadData();
         }

         private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
         {

             string filter = comboBoxFilter.SelectedItem.ToString();
             string value = txtSearch.Text.Trim();

             string whereClause = "";

             if (filter == "Student ID")
             {
                 whereClause = "WHERE s.StudentID = " + value;
             }
             else if (filter == "Student Name")
             {
                 whereClause = "WHERE s.Name LIKE '%" + value + "%'";
             }
             else if (filter == "Course Code")
             {
                 whereClause = "WHERE c.CourseCode LIKE '%" + value + "%'";
             }

             LoadData(whereClause);
         }*/

        private void btnBack_Click(object sender, EventArgs e)
        {
            _parentForm.Show();
            this.Hide();
        }

        private void btnView_Click(object sender, EventArgs e)
        {

            string searchBy = comboBoxFilter.SelectedItem?.ToString();
            string searchValue = txtSearch.Text.Trim();

            LoadQuizResults(searchBy, searchValue);
        }
        
        private void LoadQuizResults(string searchBy, string searchValue)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("SELECT * FROM GetQuizResults(@StudentID, @StudentName, @CourseCode)", con))
            {
                // default NULLs
                cmd.Parameters.Add("@StudentID", SqlDbType.Int).Value = DBNull.Value;
                cmd.Parameters.Add("@StudentName", SqlDbType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("@CourseCode", SqlDbType.VarChar).Value = DBNull.Value;

                if (!string.IsNullOrWhiteSpace(searchValue))
                {
                    if (searchBy == "Student ID")
                    {
                        if (int.TryParse(searchValue, out int id))
                            cmd.Parameters["@StudentID"].Value = id;
                        else
                        {
                            MessageBox.Show("Invalid ID");
                            return;
                        }
                    }
                    else if (searchBy == "Student Name")
                    {
                        cmd.Parameters["@StudentName"].Value = searchValue;
                    }
                    else if (searchBy == "Course Code")
                    {
                        cmd.Parameters["@CourseCode"].Value = searchValue;
                    }
                }

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
            }
        }

       
    }
}
