﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
        }

        /* private void btnAddStd_Click(object sender, EventArgs e)
         {

             if (!int.TryParse(txtSem.Text, out int semester))
             {
                 MessageBox.Show("Invalid Semester");
                 return;
             }

             if (!decimal.TryParse(txtCGPA.Text, out decimal cgpa))
             {
                 MessageBox.Show("Invalid CGPA");
                 return;
             }

             using (SqlConnection con = DatabaseHelper.GetConnection())
             using (SqlCommand cmd = new SqlCommand("AddStudent", con))
             {
                 cmd.CommandType = CommandType.StoredProcedure;

                 cmd.Parameters.AddWithValue("@AdminID", 1);
                 cmd.Parameters.AddWithValue("@Name", txtSName.Text);
                 cmd.Parameters.AddWithValue("@Gender", txtGender.Text);
                 cmd.Parameters.AddWithValue("@Semester", semester);
                 cmd.Parameters.AddWithValue("@Section", txtSec.Text);
                 cmd.Parameters.AddWithValue("@CGPA", cgpa);

                 con.Open();
                 cmd.ExecuteNonQuery();

                 MessageBox.Show("Student Added Successfully");
                 ClearFields();
             }
         }*/

        private void btnAddStd_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtSem.Text, out int semester))
            {
                MessageBox.Show("Invalid Semester");
                return;
            }

            if (!decimal.TryParse(txtCGPA.Text, out decimal cgpa))
            {
                MessageBox.Show("Invalid CGPA");
                return;
            }

            int studentID = 0;

            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                con.Open();

                // STEP 1: Add Student + get ID
                using (SqlCommand cmd = new SqlCommand("AddStudent", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@AdminID", 1);
                    cmd.Parameters.AddWithValue("@Name", txtSName.Text);
                    cmd.Parameters.AddWithValue("@Gender", txtGender.Text);
                    cmd.Parameters.AddWithValue("@Semester", semester);
                    cmd.Parameters.AddWithValue("@Section", txtSec.Text);
                    cmd.Parameters.AddWithValue("@CGPA", cgpa);

                    // Get new StudentID
                    object result = cmd.ExecuteScalar();
                    studentID = Convert.ToInt32(result);
                }

                // STEP 2: Enroll Student in Course
                using (SqlCommand cmd2 = new SqlCommand("EnrollStudentInCourse", con))
                {
                    cmd2.CommandType = CommandType.StoredProcedure;

                    cmd2.Parameters.AddWithValue("@StudentID", studentID);
                    cmd2.Parameters.AddWithValue("@CourseCode", txtCourseCode.Text);

                    try
                    {
                        cmd2.ExecuteNonQuery();
                        MessageBox.Show("Student added and enrolled successfully");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Enrollment Error: " + ex.Message);
                    }
                }
            }

            ClearFields();
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form previous = new StudentManagement();
            previous.Show();
        }

        private void ClearFields()
        {
            txtSName.Clear();
            txtGender.Clear();
            txtSem.Clear();
            txtSec.Clear();
            txtCGPA.Clear();
            txtCourseCode.Clear();

            txtSName.Focus(); 
        }

    }
}
    

