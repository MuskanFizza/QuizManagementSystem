﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class StudentDashboard : Form
    {
        /*Form previousForm;
        public StudentDashboard(Form parent)
        {
            InitializeComponent();
            previousForm = parent;
        }*/

        int studentID;

        public StudentDashboard(int id)
        {
            InitializeComponent();
            studentID = id;
        }

        private void StudentDashboard_Load(object sender, EventArgs e)
        {

        }

        private void btnStudentLogout_Click(object sender, EventArgs e)
        {
         
            DialogResult result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {

               // RoleForm rf= new RoleForm(this);
                RoleForm rf= new RoleForm();
                rf.Show();
           
                this.Hide();       // close dashboard
            }
        }

        private void btnViewQuiz_Click(object sender, EventArgs e)
        {
            ViewQuizzezFormStudent vqf = new ViewQuizzezFormStudent(studentID);
            vqf.Show();
            this.Hide();
        }

        private void btnViewStdResult_Click(object sender, EventArgs e)
        {
           
        }

        private void btnViewStdResult_Click_1(object sender, EventArgs e)
        {
            ViewResultForm vrs = new ViewResultForm(this, studentID);

            vrs.Show();
            this.Hide();
        }
    }
}
