﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class EditTeacherForm : Form
    {
        public EditTeacherForm()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form previous = new TeacherManagementForm();
            previous.Show();
        }

        /*
        private void btnEditTeacher_Click(object sender, EventArgs e)
        {

            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("EditTeacher", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@TeacherID", int.Parse(txtTID.Text));
                cmd.Parameters.AddWithValue("@Name", txtTName.Text);
                cmd.Parameters.AddWithValue("@DeptID", int.Parse(txtTDeptID.Text));
                cmd.Parameters.AddWithValue("@DepartmentName", txtTDeptName.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Teacher Updated Successfully");
                ClearFields();
            }
        }*/


        private void btnEditTeacher_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                con.Open();

                // STEP 1: Update Teacher Info
                using (SqlCommand cmd = new SqlCommand("EditTeacher", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@TeacherID", int.Parse(txtTID.Text));
                    cmd.Parameters.AddWithValue("@Name", txtTName.Text);
                    cmd.Parameters.AddWithValue("@DeptID", int.Parse(txtTDeptID.Text));
                  //  cmd.Parameters.AddWithValue("@DepartmentName", txtTDeptName.Text);

                    cmd.ExecuteNonQuery();
                }

                // STEP 2: Assign / Update Course
                using (SqlCommand cmd2 = new SqlCommand("EditAssignTeacherToCourse", con))
                {
                    cmd2.CommandType = CommandType.StoredProcedure;

                    cmd2.Parameters.AddWithValue("@TeacherID", int.Parse(txtTID.Text));
                    cmd2.Parameters.AddWithValue("@CourseCode", txtCourseCode.Text);
                    cmd2.Parameters.AddWithValue("@CourseName", txtCourseName.Text);

                    cmd2.ExecuteNonQuery();
                }

                con.Close();

                MessageBox.Show("Teacher and Course Updated Successfully");
                ClearFields();
            }
        }

        private void ClearFields()
        {
            txtTID.Clear();
            txtTName.Clear();
            txtTDeptID.Clear();
            txtTDeptName.Clear();
            txtCourseCode.Clear();
            txtCourseName.Clear();

            txtTID.Focus();
        }

    }
    
}
