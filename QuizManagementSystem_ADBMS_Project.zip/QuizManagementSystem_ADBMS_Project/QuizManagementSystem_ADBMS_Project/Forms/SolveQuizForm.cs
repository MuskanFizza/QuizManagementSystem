﻿
using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class SolveQuizForm : Form
    {/*
       public SolveQuizForm()
        {
            InitializeComponent();
        }*/


        private int quizID; // Pass this from previous form
        private int studentID; // Pass this from login
        private int attemptID;

        private List<Question> questions = new List<Question>();
        private Dictionary<int, int> selectedAnswers = new Dictionary<int, int>(); // QuestionID -> SelectedOption
        private int currentIndex = 0;

        public SolveQuizForm(int quizID, int studentID)
        {
            InitializeComponent();
            this.quizID = quizID;
            this.studentID = studentID;
        }


        private void CreateAttempt()
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("StartQuizAttempt", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@StudentID", studentID);
                cmd.Parameters.AddWithValue("@QuizID", quizID);

                con.Open();

                cmd.ExecuteNonQuery();

                // Now fetch AttemptID
                string getIDQuery = "SELECT AttemptID FROM StudentQuiz WHERE StudentID=@StudentID AND QuizID=@QuizID";
                SqlCommand getCmd = new SqlCommand(getIDQuery, con);
                getCmd.Parameters.AddWithValue("@StudentID", studentID);
                getCmd.Parameters.AddWithValue("@QuizID", quizID);

                attemptID = (int)getCmd.ExecuteScalar();
            }
        }

        private void LoadQuestions()
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                string sql = "SELECT QuestionID, QuestionText, Option1, Option2, Option3, Option4, CorrectOption, Marks FROM Question WHERE QuizID = @QuizID ORDER BY QuestionID";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@QuizID", quizID);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    questions.Add(new Question
                    {
                        QuestionID = reader.GetInt32(0),
                        QuestionText = reader.GetString(1),
                        Option1 = reader.GetString(2),
                        Option2 = reader.GetString(3),
                        Option3 = reader.GetString(4),
                        Option4 = reader.GetString(5),
                        CorrectOption = reader.GetInt32(6),
                        Marks = reader.GetInt32(7)
                    });
                }
            }
        }

        private void DisplayQuestion()
        {
            if (questions.Count == 0)
            {
                MessageBox.Show("No questions found for this quiz.");
                this.Close();
                return;
            }

            Question q = questions[currentIndex];
            txtQNo.Text = (currentIndex + 1).ToString();
            txtQRemaining.Text = (questions.Count - currentIndex - 1).ToString();
            txtQuestion.Text = q.QuestionText;

            radioButton1.Text = q.Option1;
            radioButton2.Text = q.Option2;
            radioButton3.Text = q.Option3;
            radioButton4.Text = q.Option4;

            // Restore previous selection if exists
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;

            if (selectedAnswers.ContainsKey(q.QuestionID))
            {
                int selected = selectedAnswers[q.QuestionID];
                if (selected == 1) radioButton1.Checked = true;
                if (selected == 2) radioButton2.Checked = true;
                if (selected == 3) radioButton3.Checked = true;
                if (selected == 4) radioButton4.Checked = true;
            }

            btnPrevious.Enabled = currentIndex > 0;
            btnNextQ.Enabled = currentIndex < questions.Count - 1;
        }

        private void SaveCurrentAnswer()
        {
            int selectedOption = 0;
            if (radioButton1.Checked) selectedOption = 1;
            else if (radioButton2.Checked) selectedOption = 2;
            else if (radioButton3.Checked) selectedOption = 3;
            else if (radioButton4.Checked) selectedOption = 4;

            if (selectedOption > 0)
            {
                int qID = questions[currentIndex].QuestionID;
                selectedAnswers[qID] = selectedOption;
            }
        }

        private void btnSubmitQuiz_Click(object sender, EventArgs e)
        {
            SaveCurrentAnswer();

            if (MessageBox.Show("Submit quiz?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();

                try
                {
                    foreach (Question q in questions)
                    {
                        int selected = selectedAnswers.ContainsKey(q.QuestionID)
                            ? selectedAnswers[q.QuestionID]
                            : 0;

                        string insertAnswer = @"INSERT INTO StudentAnswer 
                    (AttemptID, QuestionID, SelectedOption) 
                    VALUES (@AttemptID, @QuestionID, @SelectedOption)";

                        SqlCommand cmd = new SqlCommand(insertAnswer, con, trans);
                        cmd.Parameters.AddWithValue("@AttemptID", attemptID);
                        cmd.Parameters.AddWithValue("@QuestionID", q.QuestionID);
                        cmd.Parameters.AddWithValue("@SelectedOption", selected);

                        cmd.ExecuteNonQuery();
                    }

                    trans.Commit();

                    // 🔥 Get result from DB (trigger already calculated marks)
                    string resultQuery = "SELECT MarksObtained FROM StudentQuiz WHERE AttemptID=@AttemptID";
                    SqlCommand resultCmd = new SqlCommand(resultQuery, con);
                    resultCmd.Parameters.AddWithValue("@AttemptID", attemptID);

                    int marks = Convert.ToInt32(resultCmd.ExecuteScalar());

                    int total = questions.Sum(q => q.Marks);

                    MessageBox.Show($"Quiz submitted!\nYour score: {marks}/{total}");

                    this.Close();
                    StudentDashboard sd = new StudentDashboard(studentID);
                    sd.Show();
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    MessageBox.Show("Error submitting quiz: " + ex.Message);
                }
            }
        }
        private void btnPrevious_Click(object sender, EventArgs e)
        {

            SaveCurrentAnswer();
            if (currentIndex > 0)
            {
                currentIndex--;
                DisplayQuestion();
            }
        }

        private void btnNextQ_Click(object sender, EventArgs e)
        {
            SaveCurrentAnswer();
            if (currentIndex < questions.Count - 1)
            {
                currentIndex++;
                DisplayQuestion();
            }
        }

        private void SolveQuizForm_Load(object sender, EventArgs e)
        {
            CreateAttempt(); // Insert into StudentQuiz first to get AttemptID
            LoadQuestions();
            DisplayQuestion();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            
        }
    }

    public class Question
    {
        public int QuestionID { get; set; }
        public string QuestionText { get; set; }
        public string Option1 { get; set; }
        public string Option2 { get; set; }
        public string Option3 { get; set; }
        public string Option4 { get; set; }
        public int CorrectOption { get; set; }
        public int Marks { get; set; }
    }

}





















// ================================================================================================================================

//using QuizManagementSystem_ADBMS_Project.Data;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Data.SqlClient;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;

//namespace QuizManagementSystem_ADBMS_Project.Forms
//{
//    public partial class SolveQuizForm : Form
//    {/*
//       public SolveQuizForm()
//        {
//            InitializeComponent();
//        }*/


//        private int quizID; // Pass this from previous form
//        private int studentID; // Pass this from login
//        private int attemptID;

//        private List<Question> questions = new List<Question>();
//        private Dictionary<int, int> selectedAnswers = new Dictionary<int, int>(); // QuestionID -> SelectedOption
//        private int currentIndex = 0;

//        public SolveQuizForm(int quizID, int studentID)
//        {
//            InitializeComponent();
//            this.quizID = quizID;
//            this.studentID = studentID;
//        }


//        private void CreateAttempt()
//        {
//            using (SqlConnection con = DatabaseHelper.GetConnection())
//            {
//                string sql = "INSERT INTO StudentQuiz (StudentID, QuizID) OUTPUT INSERTED.AttemptID VALUES (@StudentID, @QuizID)";
//                SqlCommand cmd = new SqlCommand(sql, con);
//                cmd.Parameters.AddWithValue("@StudentID", studentID);
//                cmd.Parameters.AddWithValue("@QuizID", quizID);
//                con.Open();
//                attemptID = (int)cmd.ExecuteScalar();
//            }
//        }

//        private void LoadQuestions()
//        {
//            using (SqlConnection con = DatabaseHelper.GetConnection())
//            {
//                string sql = "SELECT QuestionID, QuestionText, Option1, Option2, Option3, Option4, CorrectOption, Marks FROM Question WHERE QuizID = @QuizID ORDER BY QuestionID";
//                SqlCommand cmd = new SqlCommand(sql, con);
//                cmd.Parameters.AddWithValue("@QuizID", quizID);
//                con.Open();
//                SqlDataReader reader = cmd.ExecuteReader();
//                while (reader.Read())
//                {
//                    questions.Add(new Question
//                    {
//                        QuestionID = reader.GetInt32(0),
//                        QuestionText = reader.GetString(1),
//                        Option1 = reader.GetString(2),
//                        Option2 = reader.GetString(3),
//                        Option3 = reader.GetString(4),
//                        Option4 = reader.GetString(5),
//                        CorrectOption = reader.GetInt32(6),
//                        Marks = reader.GetInt32(7)
//                    });
//                }
//            }
//        }

//        private void DisplayQuestion()
//        {
//            if (questions.Count == 0)
//            {
//                MessageBox.Show("No questions found for this quiz.");
//                this.Close();
//                return;
//            }

//            Question q = questions[currentIndex];
//            txtQNo.Text = (currentIndex + 1).ToString();
//            txtQRemaining.Text = (questions.Count - currentIndex - 1).ToString();
//            txtQuestion.Text = q.QuestionText;

//            radioButton1.Text = q.Option1;
//            radioButton2.Text = q.Option2;
//            radioButton3.Text = q.Option3;
//            radioButton4.Text = q.Option4;

//            // Restore previous selection if exists
//            radioButton1.Checked = false;
//            radioButton2.Checked = false;
//            radioButton3.Checked = false;
//            radioButton4.Checked = false;

//            if (selectedAnswers.ContainsKey(q.QuestionID))
//            {
//                int selected = selectedAnswers[q.QuestionID];
//                if (selected == 1) radioButton1.Checked = true;
//                if (selected == 2) radioButton2.Checked = true;
//                if (selected == 3) radioButton3.Checked = true;
//                if (selected == 4) radioButton4.Checked = true;
//            }

//            btnPrevious.Enabled = currentIndex > 0;
//            btnNextQ.Enabled = currentIndex < questions.Count - 1;
//        }

//        private void SaveCurrentAnswer()
//        {
//            int selectedOption = 0;
//            if (radioButton1.Checked) selectedOption = 1;
//            else if (radioButton2.Checked) selectedOption = 2;
//            else if (radioButton3.Checked) selectedOption = 3;
//            else if (radioButton4.Checked) selectedOption = 4;

//            if (selectedOption > 0)
//            {
//                int qID = questions[currentIndex].QuestionID;
//                selectedAnswers[qID] = selectedOption;
//            }
//        }


//        private void btnSubmitQuiz_Click(object sender, EventArgs e)
//        {

//            SaveCurrentAnswer();

//            if (MessageBox.Show("Submit quiz?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.No)
//                return;

//            int totalMarks = 0;

//            using (SqlConnection con = DatabaseHelper.GetConnection())
//            {
//                con.Open();
//                SqlTransaction trans = con.BeginTransaction();

//                try
//                {
//                    foreach (Question q in questions)
//                    {
//                        int selected = selectedAnswers.ContainsKey(q.QuestionID) ? selectedAnswers[q.QuestionID] : 0;
//                        bool isCorrect = selected == q.CorrectOption;
//                        if (isCorrect) totalMarks += q.Marks;

//                        string insertAnswer = @"INSERT INTO StudentAnswer (AttemptID, QuestionID, SelectedOption, IsCorrect)
//                                          VALUES (@AttemptID, @QuestionID, @SelectedOption, @IsCorrect)";
//                        SqlCommand cmd = new SqlCommand(insertAnswer, con, trans);
//                        cmd.Parameters.AddWithValue("@AttemptID", attemptID);
//                        cmd.Parameters.AddWithValue("@QuestionID", q.QuestionID);
//                        cmd.Parameters.AddWithValue("@SelectedOption", selected);
//                        cmd.Parameters.AddWithValue("@IsCorrect", isCorrect);
//                        cmd.ExecuteNonQuery();
//                    }

//                    string updateQuiz = "UPDATE StudentQuiz SET MarksObtained = @Marks WHERE AttemptID = @AttemptID";
//                    SqlCommand cmdUpdate = new SqlCommand(updateQuiz, con, trans);
//                    cmdUpdate.Parameters.AddWithValue("@Marks", totalMarks);
//                    cmdUpdate.Parameters.AddWithValue("@AttemptID", attemptID);
//                    cmdUpdate.ExecuteNonQuery();

//                    trans.Commit();
//                    MessageBox.Show($"Quiz submitted! Your score: {totalMarks}/{questions.Sum(x => x.Marks)}");
//                    this.Close();
//                    StudentDashboard sd = new StudentDashboard(studentID);
//                    sd.Show();

//                }
//                catch (Exception ex)
//                {
//                    trans.Rollback();
//                    MessageBox.Show("Error submitting quiz: " + ex.Message);
//                }
//            }
//        }

//        private void btnPrevious_Click(object sender, EventArgs e)
//        {

//            SaveCurrentAnswer();
//            if (currentIndex > 0)
//            {
//                currentIndex--;
//                DisplayQuestion();
//            }
//        }

//        private void btnNextQ_Click(object sender, EventArgs e)
//        {
//            SaveCurrentAnswer();
//            if (currentIndex < questions.Count - 1)
//            {
//                currentIndex++;
//                DisplayQuestion();
//            }
//        }

//        private void SolveQuizForm_Load(object sender, EventArgs e)
//        {
//            CreateAttempt(); // Insert into StudentQuiz first to get AttemptID
//            LoadQuestions();
//            DisplayQuestion();
//        }
//    }

//    public class Question
//    {
//        public int QuestionID { get; set; }
//        public string QuestionText { get; set; }
//        public string Option1 { get; set; }
//        public string Option2 { get; set; }
//        public string Option3 { get; set; }
//        public string Option4 { get; set; }
//        public int CorrectOption { get; set; }
//        public int Marks { get; set; }
//    }

//}