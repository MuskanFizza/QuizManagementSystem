﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class TeacherDashboard : Form
    {
        /* Form previousForm;
         public TeacherDashboard(Form parent)
         {
             InitializeComponent();
             previousForm = parent;
         }*/

        private int teacherID;

        public TeacherDashboard(int id)
        {
            InitializeComponent();
            teacherID = id;
        }


        public TeacherDashboard()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }



        private void btnAdminLogout_Click_1(object sender, EventArgs e)
        {


            DialogResult result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {

               // RoleForm rf = new RoleForm(this);
               RoleForm rf = new RoleForm();
                rf.Show();

                this.Close();       // close dashboard
            }
        }

        private void btnCreateQuiz_Click(object sender, EventArgs e)
        {

        }

        private void btnManageQuiz_Click(object sender, EventArgs e)
        {
            QuizManagement qm = new QuizManagement(teacherID);
            qm.Show();
            this.Hide();
        }

        private void btnViewResult_Click(object sender, EventArgs e)
        {
            ViewResultForm vrf = new ViewResultForm(this);
            vrf.Show();
            this.Hide();
        }
    }
}
