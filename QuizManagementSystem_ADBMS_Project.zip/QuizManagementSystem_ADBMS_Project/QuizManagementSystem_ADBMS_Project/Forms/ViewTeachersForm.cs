﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class ViewTeachersForm : Form
    {
        public ViewTeachersForm()
        {
            InitializeComponent();
        }

        private void btnViewTeachers_Click(object sender, EventArgs e)
        {
            string searchBy = cmbSearchBy.SelectedItem?.ToString();
            string searchValue = txtSearchValue.Text.Trim();

            // 🔴 Validation
            if (cmbSearchBy.SelectedIndex != -1 && string.IsNullOrWhiteSpace(searchValue))
            {
                MessageBox.Show("Please enter a search value.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (searchBy == "ID")
            {
                if (!int.TryParse(searchValue, out _))
                {
                    MessageBox.Show("ID must be a valid number.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                using (SqlCommand cmd = new SqlCommand("GetTeachers", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (cmbSearchBy.SelectedIndex == -1 || string.IsNullOrWhiteSpace(searchValue))
                    {
                        cmd.Parameters.AddWithValue("@SearchBy", DBNull.Value);
                        cmd.Parameters.AddWithValue("@SearchValue", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@SearchBy", searchBy);
                        cmd.Parameters.AddWithValue("@SearchValue", searchValue);
                    }

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    con.Open();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = dt;
                    }
                    else
                    {
                        dataGridView1.DataSource = null;
                        MessageBox.Show(
                            $"No teacher found for {searchBy}: {searchValue}",
                            "Search Result",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );
                    }
                }
            }
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form previous = new TeacherManagementForm();
            previous.Show();
        }
    }
    
}
