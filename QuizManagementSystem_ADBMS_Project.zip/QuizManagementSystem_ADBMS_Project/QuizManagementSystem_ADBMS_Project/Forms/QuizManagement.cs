﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class QuizManagement : Form
    {
        int teacherID;
        public QuizManagement(int id)
        {
            InitializeComponent();
            teacherID = id;
        }

        private void btnCreateQuiz_Click(object sender, EventArgs e)
        {
            QuizCreationForm form = new QuizCreationForm(teacherID);
            form.Show();
            this.Hide();
        }
      

        private void btnEditQuiz_Click(object sender, EventArgs e)
        {
            EditQuizForm eqf = new EditQuizForm(teacherID);
            eqf.Show();
            this.Hide();
        }

        private void btnDeleteQuiz_Click(object sender, EventArgs e)
        {
            DeleteQuizForm dqf = new DeleteQuizForm(teacherID);
            dqf.Show();

            this.Hide();
        }

        private void btnViewQuiz_Click(object sender, EventArgs e)
        {
           // ViewQuestionsForm qf = new ViewQuestionsForm();
           ViewQuizFormTeacher vqf = new ViewQuizFormTeacher(teacherID);
           vqf.Show();  

            this.Hide();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            TeacherDashboard tdb = new TeacherDashboard();   
            tdb.Show();
            this.Hide();
        }
    }
}
