﻿namespace QuizManagementSystem_ADBMS_Project.Forms
{
    partial class StudentDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnViewStdResult = new System.Windows.Forms.Button();
            this.btnViewQuiz = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnStudentLogout = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnViewStdResult
            // 
            this.btnViewStdResult.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewStdResult.Location = new System.Drawing.Point(398, 227);
            this.btnViewStdResult.Name = "btnViewStdResult";
            this.btnViewStdResult.Size = new System.Drawing.Size(146, 48);
            this.btnViewStdResult.TabIndex = 23;
            this.btnViewStdResult.Text = "View Results";
            this.btnViewStdResult.UseVisualStyleBackColor = true;
            this.btnViewStdResult.Click += new System.EventHandler(this.btnViewStdResult_Click_1);
            // 
            // btnViewQuiz
            // 
            this.btnViewQuiz.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewQuiz.Location = new System.Drawing.Point(226, 227);
            this.btnViewQuiz.Name = "btnViewQuiz";
            this.btnViewQuiz.Size = new System.Drawing.Size(146, 48);
            this.btnViewQuiz.TabIndex = 21;
            this.btnViewQuiz.Text = "View Quizzes";
            this.btnViewQuiz.UseVisualStyleBackColor = true;
            this.btnViewQuiz.Click += new System.EventHandler(this.btnViewQuiz_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(248, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(275, 25);
            this.label1.TabIndex = 20;
            this.label1.Text = "STUDENT DASHBOARD";
            // 
            // btnStudentLogout
            // 
            this.btnStudentLogout.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStudentLogout.Location = new System.Drawing.Point(326, 329);
            this.btnStudentLogout.Name = "btnStudentLogout";
            this.btnStudentLogout.Size = new System.Drawing.Size(116, 35);
            this.btnStudentLogout.TabIndex = 24;
            this.btnStudentLogout.Text = "Logout";
            this.btnStudentLogout.UseVisualStyleBackColor = true;
            this.btnStudentLogout.Click += new System.EventHandler(this.btnStudentLogout_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Algerian", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(178, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(400, 31);
            this.label2.TabIndex = 26;
            this.label2.Text = "QUIZ MANAGEMENT SYSTEM";
            // 
            // StudentDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnStudentLogout);
            this.Controls.Add(this.btnViewStdResult);
            this.Controls.Add(this.btnViewQuiz);
            this.Controls.Add(this.label1);
            this.Name = "StudentDashboard";
            this.Text = "Student Dashboard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnViewStdResult;
        private System.Windows.Forms.Button btnViewQuiz;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnStudentLogout;
        private System.Windows.Forms.Label label2;
    }
}