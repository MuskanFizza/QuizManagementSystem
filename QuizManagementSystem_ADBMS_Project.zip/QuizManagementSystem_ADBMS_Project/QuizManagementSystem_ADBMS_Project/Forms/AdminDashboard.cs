﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class AdminDashboard : Form
    {
        Form previousForm;
        public AdminDashboard(Form parent)
       // public AdminDashboard()
        {
            InitializeComponent();
            previousForm = parent;
        }

        private void btnAdminLogout_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show(
                "Are you sure you want to logout?",
                "Logout",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {

                //RoleForm rf = new RoleForm(this);
                RoleForm rf = new RoleForm();
                rf.Show();

                this.Close();       // close dashboard
            }
        }


        private void btb_adminManageTeacher_Click(object sender, EventArgs e)
        {
            TeacherManagementForm tmf = new TeacherManagementForm();
            tmf.Show();
            this.Hide();
        }

        private void btn_adminViewResult_Click(object sender, EventArgs e)
        {
            ViewResultForm view = new ViewResultForm(this);
            view.Show();
            this.Hide();
        }

        private void btn_adminManageStudent_Click_1(object sender, EventArgs e)
        {
            StudentManagement smf = new StudentManagement();
            smf.Show();
            this.Hide();
        }
    }

}
