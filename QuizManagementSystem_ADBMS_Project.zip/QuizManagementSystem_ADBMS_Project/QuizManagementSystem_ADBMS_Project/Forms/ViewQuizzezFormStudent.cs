﻿using QuizManagementSystem_ADBMS_Project.Data;
using QuizManagementSystem_ADBMS_Project.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class ViewQuizzezFormStudent : Form
    {
        private bool isFormLoaded = false;
        int studentID;

        public ViewQuizzezFormStudent(int id)
        {
            InitializeComponent();
            studentID = id;
            dataGridView1.CellClick += dataGridView1_CellClick;
        }


        private void btnView_Click(object sender, EventArgs e)
        {
            string searchBy = comboBoxFilter.Text;
            string searchValue = txtSearchValue.Text;

            LoadQuizDetails(searchBy, searchValue);
        }

        private void LoadStudentCourses(int studentID)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("GetStudentCourses", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StudentID", studentID);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);

                cmbCourses.DataSource = dt;
                cmbCourses.DisplayMember = "CourseName";
                cmbCourses.ValueMember = "CourseCode";
            }
        }


        private void LoadQuizDetails(string searchBy = null, string searchValue = null)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("GetQuizDetailsForStudent", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@StudentID", studentID);

                cmd.Parameters.AddWithValue("@SearchBy",
                    string.IsNullOrEmpty(searchBy) ? (object)DBNull.Value : searchBy);

                cmd.Parameters.AddWithValue("@SearchValue",
                    string.IsNullOrEmpty(searchValue) ? (object)DBNull.Value : searchValue);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                try
                {
                    con.Open();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No quiz details found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void LoadQuizzesByCourse(string courseCode)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("GetQuizzesByStudentCourse", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@StudentID", studentID);
                cmd.Parameters.AddWithValue("@CourseCode", courseCode);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                try
                {
                    con.Open();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No quizzes found for this course.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }


        private void btnBack_Click_1(object sender, EventArgs e)
        {
            StudentDashboard sd = new StudentDashboard(studentID);
            sd.Show();
            this.Hide();
        }

        private void cmbCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormLoaded) return;

            if (cmbCourses.SelectedValue == null) return;

            string courseCode = cmbCourses.SelectedValue.ToString();

            LoadQuizzesByCourse(courseCode);
        }

        private void ViewQuizzezFormStudent_Load(object sender, EventArgs e)
        {

            LoadStudentCourses(studentID);

            isFormLoaded = true;

            if (cmbCourses.Items.Count > 0)
            {
                cmbCourses.SelectedIndex = 0;
            }
        }

        private bool HasAlreadyAttempted(int quizID)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand(
                "SELECT COUNT(*) FROM StudentQuiz WHERE StudentID=@StudentID AND QuizID=@QuizID", con))
            {
                cmd.Parameters.AddWithValue("@StudentID", studentID);
                cmd.Parameters.AddWithValue("@QuizID", quizID);

                con.Open();

                int count = (int)cmd.ExecuteScalar();

                return count > 0;
            }
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            // Get QuizID safely
            if (!int.TryParse(row.Cells["QuizID"]?.Value?.ToString(), out int quizID))
                return;

            string clickedColumn = dataGridView1.Columns[e.ColumnIndex].Name;

            // ✅ If user clicks QuizID → Attempt Quiz
            if (clickedColumn == "QuizID")
            {
                if (HasAlreadyAttempted(quizID))
                {
                    MessageBox.Show("You have already attempted this quiz.");
                    return;
                }

                AttemptForm attempt = new AttemptForm(quizID, studentID);
                attempt.Show();
                this.Hide();
            }

            // ✅ Optional: If you still want Question click → Solve
            else if (clickedColumn == "QuestionID")
            {
                SolveQuizForm solve = new SolveQuizForm(quizID, studentID);
                solve.Show();
                this.Hide();
            }
        }
        /*private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            string quizIDStr = row.Cells["QuizID"]?.Value?.ToString();
            string questionID = row.Cells["QuestionID"]?.Value?.ToString();

            if (string.IsNullOrEmpty(quizIDStr)) return;

            int quizID = int.Parse(quizIDStr);

            // 🔥 CHECK HERE
            if (HasAlreadyAttempted(quizID))
            {
                MessageBox.Show("You have already attempted this quiz.");
                return;
            }

            // 🔵 If clicked on Question → Solve
            if (dataGridView1.Columns[e.ColumnIndex].Name == "QuizTitle")
            {
                if (!string.IsNullOrEmpty(questionID))
                {
                    SolveQuizForm solve = new SolveQuizForm(quizID, studentID);
                    solve.Show();
                    this.Hide();
                }
            }
            else
            {
                // 🟢 Attempt quiz
                AttemptForm attempt = new AttemptForm(quizID, studentID);
                attempt.Show();
                this.Hide();
            }
        }*/
    }
}