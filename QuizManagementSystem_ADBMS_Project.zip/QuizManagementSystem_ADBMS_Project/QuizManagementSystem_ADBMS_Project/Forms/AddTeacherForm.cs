﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class AddTeacherForm : Form
    {
        public AddTeacherForm()
        {
            InitializeComponent();
        }

        private void btnAddTeacher_Click(object sender, EventArgs e)
        {
           /* using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("AddTeacher", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@AdminID", 1); 
                cmd.Parameters.AddWithValue("@Name", txtTName.Text);
                cmd.Parameters.AddWithValue("@TDept", txtDeptName.Text);
                cmd.Parameters.AddWithValue("@DeptID", int.Parse(txtDeptID.Text));

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Teacher Added Successfully");

                ClearFields();
            }
        }



        private void btnAddTeacher_Click(object sender, EventArgs e)
        {*/
            int teacherID = 0;

            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                con.Open();

                // STEP 1: Add Teacher and GET ID
                using (SqlCommand cmd = new SqlCommand("AddTeacher", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@AdminID", 1);
                    cmd.Parameters.AddWithValue("@Name", txtTName.Text);
                    cmd.Parameters.AddWithValue("@TDept", txtDeptName.Text);
                    cmd.Parameters.AddWithValue("@DeptID", int.Parse(txtDeptID.Text));

                    // Get returned TeacherID
                    object result = cmd.ExecuteScalar();
                    teacherID = Convert.ToInt32(result);
                }

                MessageBox.Show("Teacher Added Successfully");

                // STEP 2: Assign Course using SAME teacherID
                using (SqlCommand cmd2 = new SqlCommand("AssignTeacherToCourse", con))
                {
                    cmd2.CommandType = CommandType.StoredProcedure;

                    cmd2.Parameters.AddWithValue("@TeacherID", teacherID);
                    cmd2.Parameters.AddWithValue("@CourseCode", txtCourseCode.Text);
                    cmd2.Parameters.AddWithValue("@CourseName", txtCourseName.Text);

                    try
                    {
                        cmd2.ExecuteNonQuery();
                        MessageBox.Show("Teacher assigned to course successfully");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }

            ClearFields();
        }



    private void btnBack_Click(object sender, EventArgs e)
        {
    
            this.Hide();
            Form previous = new TeacherManagementForm();
            previous.Show();
        }

        private void ClearFields()
        {
            txtTName.Clear();
            txtDeptName.Clear();
            txtDeptID.Clear();
            txtCourseCode.Clear();
            txtCourseName.Clear();
      

            txtTName.Focus(); 
        }

        private void AddTeacherForm_Load(object sender, EventArgs e)
        {

        }
    }
}
