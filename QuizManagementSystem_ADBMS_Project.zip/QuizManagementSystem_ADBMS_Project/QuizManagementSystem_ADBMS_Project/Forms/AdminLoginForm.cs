﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class AdminLoginForm : Form
    {

        Form previousForm;

        public AdminLoginForm(Form parent)
        {
            InitializeComponent();
            previousForm = parent;
        }

        private void btnaAdminLogin_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                try
                {
                    con.Open();

                    string query = "SELECT COUNT(*) FROM Admins WHERE AEmail=@email AND APassword=@pass";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@email", txtAdminUsername.Text);
                    cmd.Parameters.AddWithValue("@pass", txtAdminPassword.Text);

                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("✅ Login Successful!");

                        AdminDashboard aDash = new AdminDashboard(this);
                        aDash.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("❌ Invalid Username or Password");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }



        private void btnBack_Click(object sender, EventArgs e)
        {
            previousForm.Show();
            this.Close();
        }

        private void AdminLoginForm_Load(object sender, EventArgs e)
        {
            txtAdminPassword.UseSystemPasswordChar = true;

        }

     

        private void checkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtAdminPassword.UseSystemPasswordChar = !checkShowPassword.Checked;

        }
    }
}