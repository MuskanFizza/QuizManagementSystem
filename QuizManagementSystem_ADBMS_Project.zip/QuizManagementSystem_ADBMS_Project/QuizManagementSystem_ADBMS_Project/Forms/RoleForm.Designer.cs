﻿namespace QuizManagementSystem_ADBMS_Project.Forms
{
    partial class RoleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rb_teacher = new System.Windows.Forms.RadioButton();
            this.rb_Student = new System.Windows.Forms.RadioButton();
            this.rb_admin = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(215, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 31);
            this.label1.TabIndex = 5;
            this.label1.Text = "QUIZ MANAGEMENT SYSTEM";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(319, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 23);
            this.label2.TabIndex = 6;
            this.label2.Text = "SELECT ROLE";
            // 
            // rb_teacher
            // 
            this.rb_teacher.AutoSize = true;
            this.rb_teacher.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rb_teacher.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_teacher.Location = new System.Drawing.Point(339, 240);
            this.rb_teacher.Name = "rb_teacher";
            this.rb_teacher.Size = new System.Drawing.Size(104, 23);
            this.rb_teacher.TabIndex = 7;
            this.rb_teacher.Text = "TEACHER";
            this.rb_teacher.UseVisualStyleBackColor = true;
            this.rb_teacher.CheckedChanged += new System.EventHandler(this.rb_teacher_CheckedChanged);
            // 
            // rb_Student
            // 
            this.rb_Student.AutoSize = true;
            this.rb_Student.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rb_Student.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Student.Location = new System.Drawing.Point(490, 240);
            this.rb_Student.Name = "rb_Student";
            this.rb_Student.Size = new System.Drawing.Size(103, 23);
            this.rb_Student.TabIndex = 8;
            this.rb_Student.Text = "STUDENT";
            this.rb_Student.UseVisualStyleBackColor = true;
            this.rb_Student.CheckedChanged += new System.EventHandler(this.rb_Student_CheckedChanged);
            // 
            // rb_admin
            // 
            this.rb_admin.AutoSize = true;
            this.rb_admin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rb_admin.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_admin.Location = new System.Drawing.Point(201, 240);
            this.rb_admin.Name = "rb_admin";
            this.rb_admin.Size = new System.Drawing.Size(85, 23);
            this.rb_admin.TabIndex = 9;
            this.rb_admin.Text = "ADMIN";
            this.rb_admin.UseVisualStyleBackColor = true;
            this.rb_admin.CheckedChanged += new System.EventHandler(this.rb_admin_CheckedChanged);
            // 
            // RoleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rb_admin);
            this.Controls.Add(this.rb_Student);
            this.Controls.Add(this.rb_teacher);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "RoleForm";
            this.Text = "RoleForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rb_teacher;
        private System.Windows.Forms.RadioButton rb_Student;
        private System.Windows.Forms.RadioButton rb_admin;
    }
}