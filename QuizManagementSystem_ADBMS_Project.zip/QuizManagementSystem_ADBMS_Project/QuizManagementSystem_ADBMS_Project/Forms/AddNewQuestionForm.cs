﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class AddNewQuestionForm : Form
    {
       // private string TQNo;
        private string courseCode;
        private string quizNumber;
        int teacherID;

        public AddNewQuestionForm(string courseCode, string quizNumber, int teacherID)
        {
            InitializeComponent();
          //  this.TQNo = TQNo;
            this.courseCode = courseCode;
            this.quizNumber = quizNumber;
            this.teacherID = teacherID;
        }

        private void btnAddQuestion_Click(object sender, EventArgs e)
        {
            AddQuestion(int.Parse(txtQuizID.Text));
        }
        private void AddQuestion(int quizID)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("AddQuestion", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@QuizID", quizID);
                cmd.Parameters.AddWithValue("@Text", txtQuestion.Text);
                cmd.Parameters.AddWithValue("@O1", txtO1.Text);
                cmd.Parameters.AddWithValue("@O2", txtO2.Text);
                cmd.Parameters.AddWithValue("@O3", txtO3.Text);
                cmd.Parameters.AddWithValue("@O4", txtO4.Text);
                cmd.Parameters.AddWithValue("@Correct", int.Parse(txtCO.Text));
                cmd.Parameters.AddWithValue("@Marks", int.Parse(txtQMarks.Text));

                try
                {
                    con.Open();

                    // Get message from SQL
                    string message = cmd.ExecuteScalar()?.ToString();

                    MessageBox.Show(message);

                    // Only clear if successful
                    if (message == "Question added successfully")
                    {
                        ClearFields();
                    }
                    if (message == "Question limit reached")
                    {
                        MessageBox.Show("Quiz Created Successfully!");
                        EditQuizForm eqf = new EditQuizForm(teacherID);
                        eqf.Show();
                        this.Hide();
                    }
                }
                catch (Exception ex)
                {
                 
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            QuizManagement eqf = new QuizManagement(teacherID);
            eqf.Show();
            this.Hide();
        
       }

        private void ClearFields()
        {
            txtQuestion.Clear();
            txtO1.Clear();
            txtO2.Clear();
            txtO3.Clear();
            txtO4.Clear();
            txtCO.Clear();
            txtQMarks.Clear();
            txtQuizID.Clear();
      
        }
    }
}
