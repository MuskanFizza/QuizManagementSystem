﻿namespace QuizManagementSystem_ADBMS_Project.Forms
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.btn_adminManageStudent = new System.Windows.Forms.Button();
            this.btn_adminManageTeacher = new System.Windows.Forms.Button();
            this.btnAdminLogout = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_adminViewResult = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(259, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(248, 25);
            this.label4.TabIndex = 15;
            this.label4.Text = "ADMIN DASHBOARD";
            // 
            // btn_adminManageStudent
            // 
            this.btn_adminManageStudent.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_adminManageStudent.Location = new System.Drawing.Point(310, 209);
            this.btn_adminManageStudent.Name = "btn_adminManageStudent";
            this.btn_adminManageStudent.Size = new System.Drawing.Size(146, 65);
            this.btn_adminManageStudent.TabIndex = 18;
            this.btn_adminManageStudent.Text = "Manage Student";
            this.btn_adminManageStudent.UseVisualStyleBackColor = true;
            this.btn_adminManageStudent.Click += new System.EventHandler(this.btn_adminManageStudent_Click_1);
            // 
            // btn_adminManageTeacher
            // 
            this.btn_adminManageTeacher.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_adminManageTeacher.Location = new System.Drawing.Point(136, 209);
            this.btn_adminManageTeacher.Name = "btn_adminManageTeacher";
            this.btn_adminManageTeacher.Size = new System.Drawing.Size(146, 65);
            this.btn_adminManageTeacher.TabIndex = 19;
            this.btn_adminManageTeacher.Text = "Manage Teacher";
            this.btn_adminManageTeacher.UseVisualStyleBackColor = true;
            this.btn_adminManageTeacher.Click += new System.EventHandler(this.btb_adminManageTeacher_Click);
            // 
            // btnAdminLogout
            // 
            this.btnAdminLogout.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdminLogout.Location = new System.Drawing.Point(324, 349);
            this.btnAdminLogout.Name = "btnAdminLogout";
            this.btnAdminLogout.Size = new System.Drawing.Size(116, 35);
            this.btnAdminLogout.TabIndex = 20;
            this.btnAdminLogout.Text = "Logout";
            this.btnAdminLogout.UseVisualStyleBackColor = true;
            this.btnAdminLogout.Click += new System.EventHandler(this.btnAdminLogout_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(193, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 31);
            this.label1.TabIndex = 22;
            this.label1.Text = "QUIZ MANAGEMENT SYSTEM";
            // 
            // btn_adminViewResult
            // 
            this.btn_adminViewResult.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_adminViewResult.Location = new System.Drawing.Point(481, 209);
            this.btn_adminViewResult.Name = "btn_adminViewResult";
            this.btn_adminViewResult.Size = new System.Drawing.Size(146, 65);
            this.btn_adminViewResult.TabIndex = 17;
            this.btn_adminViewResult.Text = "View Result";
            this.btn_adminViewResult.UseVisualStyleBackColor = true;
            this.btn_adminViewResult.Click += new System.EventHandler(this.btn_adminViewResult_Click);
            // 
            // AdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAdminLogout);
            this.Controls.Add(this.btn_adminManageTeacher);
            this.Controls.Add(this.btn_adminManageStudent);
            this.Controls.Add(this.btn_adminViewResult);
            this.Controls.Add(this.label4);
            this.Name = "AdminDashboard";
            this.Text = "AdminDashboard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_adminManageStudent;
        private System.Windows.Forms.Button btn_adminManageTeacher;
        private System.Windows.Forms.Button btnAdminLogout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_adminViewResult;
    }
}