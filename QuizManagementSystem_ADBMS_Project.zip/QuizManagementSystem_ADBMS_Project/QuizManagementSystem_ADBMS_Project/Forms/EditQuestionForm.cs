﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class EditQuestionForm : Form
    {
        int teacherID;
        private string courseCode;
        private string quizNumber;

        public EditQuestionForm(int tid, string courseCode, string quizNumber)
        {
            InitializeComponent();
            this.courseCode = courseCode;
            this.quizNumber = quizNumber;
            this.teacherID = tid;
        }

        private void btnUpdateQuestion_Click(object sender, EventArgs e)
        {
           
            if (!int.TryParse(txtQuestionID.Text, out int questionID))
            {
                MessageBox.Show("Invalid Question ID");
                return;
            }

            if (!int.TryParse(txtCO.Text, out int correctOption))
            {
                MessageBox.Show("Correct option must be a number (1-4)");
                return;
            }

            if (!int.TryParse(txtQMarks.Text, out int marks))
            {
                MessageBox.Show("Invalid marks");
                return;
            }

            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("EditQuestion", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                // Parameters
                cmd.Parameters.AddWithValue("@QuestionID", questionID);
                cmd.Parameters.AddWithValue("@QuestionText", txtQuestion.Text);
                cmd.Parameters.AddWithValue("@Opt1", txtO1.Text);
                cmd.Parameters.AddWithValue("@Opt2", txtO2.Text);
                cmd.Parameters.AddWithValue("@Opt3", txtO3.Text);
                cmd.Parameters.AddWithValue("@Opt4", txtO4.Text);
                cmd.Parameters.AddWithValue("@CorrectOption", correctOption);
                cmd.Parameters.AddWithValue("@Marks", marks);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Question updated successfully");
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
       /* private void EditQuestion(int questionID)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("EditQuestion", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                //  cmd.Parameters.AddWithValue("@Q", quizID);
                cmd.Parameters.AddWithValue("@Text", txtQuestion.Text);
                cmd.Parameters.AddWithValue("@O1", txtO1.Text);
                cmd.Parameters.AddWithValue("@O2", txtO2.Text);
                cmd.Parameters.AddWithValue("@O3", txtO3.Text);
                cmd.Parameters.AddWithValue("@O4", txtO4.Text);
                cmd.Parameters.AddWithValue("@Correct", int.Parse(txtCO.Text));
                cmd.Parameters.AddWithValue("@Marks", int.Parse(txtQMarks.Text));

                con.Open();
                cmd.ExecuteNonQuery();

                MessageBox.Show("Question Edited");
            }
        }*/

        public void ClearFields()
        {
            txtQuestion.Clear();
            txtO1.Clear();
            txtO2.Clear();
            txtO3.Clear();
            txtO4.Clear();
            txtCO.Clear();
            txtQMarks.Clear();
            txtQuestion.Clear();
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            EditQuizForm eqf = new EditQuizForm(teacherID);
            eqf.Show();
            this.Hide();
        }
    }
    

}
