﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class RoleForm : Form
    {
        /*Form previousForm;

        public RoleForm(Form parent)
        {
            InitializeComponent();
            previousForm = parent;
        }*/

        public RoleForm()
        {
            InitializeComponent();
        }



        private void rb_admin_CheckedChanged(object sender, EventArgs e)
        {
            AdminLoginForm alf = new AdminLoginForm(this);
            alf.Show();
           // this.Close();
            this.Hide();


        }

        private void rb_teacher_CheckedChanged(object sender, EventArgs e)
        {
            TeacherLoginForm tlf = new TeacherLoginForm(this);
            tlf.Show();
            this.Hide();
        }

        private void rb_Student_CheckedChanged(object sender, EventArgs e)
        {
            StudentLoginForm slf = new StudentLoginForm(this);
            slf.Show();
            this.Hide();
        }


        /*
         CONTINUE BUTTON 


        private void btnContinue_Click(object sender, EventArgs e)
{
    string selectedRole = null;

    if (rbAdmin.Checked) selectedRole = "Admin";
    else if (rbTeacher.Checked) selectedRole = "Teacher";
    else if (rbStudent.Checked) selectedRole = "Student";

    if (selectedRole == null)
    {
        MessageBox.Show("Please select a role.");
        return;
    }

    // Open Login Form and pass role
    LoginForm login = new LoginForm(selectedRole);
    login.Show();
    this.Hide();
}

        */
    }
}
