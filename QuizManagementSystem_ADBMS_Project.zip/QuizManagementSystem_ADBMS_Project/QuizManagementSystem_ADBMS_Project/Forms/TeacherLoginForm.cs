﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class TeacherLoginForm : Form
    {
        Form previousForm;

        public TeacherLoginForm(Form parent)
        {
            InitializeComponent();
            previousForm = parent;
        }
      
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnAdminLogin_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                try
                {
                    con.Open();

                    string query = @"SELECT TeacherID, TName 
                             FROM Teacher 
                             WHERE TEmail=@email AND TPassword=@pass";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@email", txtTeacherUsername.Text);
                    cmd.Parameters.AddWithValue("@pass", txtTeacherPassword.Text);

                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        int teacherID = Convert.ToInt32(dr["TeacherID"]);
                        string name = Convert.ToString(dr["TName"]);

                        MessageBox.Show("Welcome " + name);

                        // PASS TEACHER ID TO DASHBOARD
                        TeacherDashboard aDash = new TeacherDashboard(teacherID);
                        aDash.Show();

                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

       /* private void btnAdminLogin_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                try
                {
                    con.Open();

                    string query = "SELECT COUNT(*) FROM Teacher WHERE TEmail=@email AND TPassword=@pass";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@email", txtTeacherUsername.Text);
                    cmd.Parameters.AddWithValue("@pass", txtTeacherPassword.Text);

                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("✅ Login Successful!");

                        TeacherDashboard aDash = new TeacherDashboard();
                        aDash.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("❌ Invalid Username or Password");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }*/

        private void TeacherLoginForm_Load(object sender, EventArgs e)
        {

            txtTeacherPassword.UseSystemPasswordChar = true;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            RoleForm rf = new RoleForm();
            //previousForm.Show();
            rf.Show();
            this.Close();
        }


        private void checkShowPassword_CheckedChanged_1(object sender, EventArgs e)
        {
       
            txtTeacherPassword.UseSystemPasswordChar = !checkShowPassword.Checked;

        }
    
    }
}
