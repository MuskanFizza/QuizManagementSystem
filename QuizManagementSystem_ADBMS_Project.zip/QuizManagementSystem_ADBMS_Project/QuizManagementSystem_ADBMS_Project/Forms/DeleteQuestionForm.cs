﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class DeleteQuestionForm : Form
    {


        private string courseCode;
        private string quizNumber;
        int id;

        public DeleteQuestionForm(string courseCode, string quizNumber, int id)
        {
            InitializeComponent();
            this.courseCode = courseCode;
            this.quizNumber = quizNumber;
            this.id = id;
        }
        public DeleteQuestionForm()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteQuestion(int.Parse(txtDeleteQ.Text));
        }


        private void DeleteQuestion(int questionID)
        {
            // Basic validation
            if (questionID <= 0)
            {
                MessageBox.Show("Invalid Question ID");
                return;
            }

            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("DeleteQuestion", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@QuestionID", questionID);

                try
                {
                    con.Open();

                    // Get result message
                    string message = cmd.ExecuteScalar()?.ToString();

                    MessageBox.Show(message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            QuizManagement tdb = new QuizManagement(id);
            tdb.Show();
            this.Hide();
        }
    }
}
