﻿namespace QuizManagementSystem_ADBMS_Project.Forms
{
    partial class TeacherDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnTeacherLogout = new System.Windows.Forms.Button();
            this.btnManageQuiz = new System.Windows.Forms.Button();
            this.btnViewResult = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(201, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 31);
            this.label1.TabIndex = 30;
            this.label1.Text = "QUIZ MANAGEMENT SYSTEM";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnTeacherLogout
            // 
            this.btnTeacherLogout.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeacherLogout.Location = new System.Drawing.Point(346, 363);
            this.btnTeacherLogout.Name = "btnTeacherLogout";
            this.btnTeacherLogout.Size = new System.Drawing.Size(116, 35);
            this.btnTeacherLogout.TabIndex = 28;
            this.btnTeacherLogout.Text = "Logout";
            this.btnTeacherLogout.UseVisualStyleBackColor = true;
            this.btnTeacherLogout.Click += new System.EventHandler(this.btnAdminLogout_Click_1);
            // 
            // btnManageQuiz
            // 
            this.btnManageQuiz.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageQuiz.Location = new System.Drawing.Point(252, 229);
            this.btnManageQuiz.Name = "btnManageQuiz";
            this.btnManageQuiz.Size = new System.Drawing.Size(146, 48);
            this.btnManageQuiz.TabIndex = 27;
            this.btnManageQuiz.Text = "Manage Quiz";
            this.btnManageQuiz.UseVisualStyleBackColor = true;
            this.btnManageQuiz.Click += new System.EventHandler(this.btnManageQuiz_Click);
            // 
            // btnViewResult
            // 
            this.btnViewResult.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewResult.Location = new System.Drawing.Point(424, 229);
            this.btnViewResult.Name = "btnViewResult";
            this.btnViewResult.Size = new System.Drawing.Size(146, 48);
            this.btnViewResult.TabIndex = 25;
            this.btnViewResult.Text = "View Result";
            this.btnViewResult.UseVisualStyleBackColor = true;
            this.btnViewResult.Click += new System.EventHandler(this.btnViewResult_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(269, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(279, 25);
            this.label4.TabIndex = 23;
            this.label4.Text = "TEACHER DASHBOARD";
            // 
            // TeacherDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnTeacherLogout);
            this.Controls.Add(this.btnManageQuiz);
            this.Controls.Add(this.btnViewResult);
            this.Controls.Add(this.label4);
            this.Name = "TeacherDashboard";
            this.Text = "TeacherDashboard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTeacherLogout;
        private System.Windows.Forms.Button btnManageQuiz;
        private System.Windows.Forms.Button btnViewResult;
        private System.Windows.Forms.Label label4;
    }
}