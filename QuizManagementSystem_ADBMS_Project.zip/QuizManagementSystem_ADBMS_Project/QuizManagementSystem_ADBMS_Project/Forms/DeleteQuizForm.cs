﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class DeleteQuizForm : Form
    {
        int teacherID;
        public DeleteQuizForm(int id)
        {
            InitializeComponent();
            teacherID = id;
        }

        
        private void DeleteQuiz(int quizID)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("DeleteEntireQuizForceful", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@QuizID", quizID);

                try
                {
                    con.Open();

                    string message = cmd.ExecuteScalar()?.ToString();
                    MessageBox.Show(message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void txtDeleteQ_TextChanged(object sender, EventArgs e)
        {
         //   DeleteQuiz(int.Parse(txtDeleteQuizID.Text));
        }

        private void btnDeleteQuiz_Click(object sender, EventArgs e)
        {
            DeleteQuiz(int.Parse(txtDeleteQuizID.Text));

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            QuizManagement qm = new QuizManagement(teacherID);
            qm.Show();
            this.Hide();
        }
    }
}
