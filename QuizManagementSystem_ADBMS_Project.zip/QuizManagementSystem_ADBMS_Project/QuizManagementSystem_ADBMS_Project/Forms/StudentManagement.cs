﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class StudentManagement : Form
    {
        public StudentManagement()
        {
            InitializeComponent();
        }

        private void btnAddStd_Click(object sender, EventArgs e)
        {
            StudentForm studentForm = new StudentForm();
            studentForm.Show();
            this.Hide();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminDashboard ad = new AdminDashboard(this);
            ad.Show();
            this.Close();
        }

        private void btnViewStds_Click(object sender, EventArgs e)
        {
            ViewStudents vs = new ViewStudents();
            vs.Show();
            this.Hide();                
        }

        private void btnEditStd_Click(object sender, EventArgs e)
        {
            EditStudent es = new EditStudent();
            es.Show();
            this.Hide();
        }

        private void btbDelStd_Click(object sender, EventArgs e)
        {
            DeleteStudent ds = new DeleteStudent();
            ds.Show();
            this.Hide();
        }
    }
}
