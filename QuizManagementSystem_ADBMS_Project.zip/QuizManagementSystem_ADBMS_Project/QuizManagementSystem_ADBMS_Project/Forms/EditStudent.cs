﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class EditStudent : Form
    {
        public EditStudent()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form previous = new StudentManagement();
            previous.Show();
        }

        private void ClearFields()
        {
            txtSID.Clear();
            txtSName.Clear();
            txtGender.Clear();
            txtSem.Clear();
            txtSection.Clear();
            txtCGPA.Clear();
            txtCourseCode.Clear();

            txtSID.Focus(); 
        }

        private void btnEditStd_Click(object sender, EventArgs e)
        {
           /* if (!int.TryParse(txtSID.Text, out int id))
            {
                MessageBox.Show("Invalid Student ID");
                return;
            }

            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("EditStudent", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@StudentID", id);
                cmd.Parameters.AddWithValue("@Name", txtSName.Text);
                cmd.Parameters.AddWithValue("@Gender", txtGender.Text);
                cmd.Parameters.AddWithValue("@Semester", int.Parse(txtSem.Text));
                cmd.Parameters.AddWithValue("@Section", txtSection.Text);
                cmd.Parameters.AddWithValue("@CGPA", decimal.Parse(txtCGPA.Text));

                con.Open();
                cmd.ExecuteNonQuery();

                MessageBox.Show("Student Updated Successfully");
                ClearFields();
            }
           */

            if (!int.TryParse(txtSID.Text, out int id))
            {
                MessageBox.Show("Invalid Student ID");
                return;
            }

            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                con.Open();

                // 1️⃣ Update student
                using (SqlCommand cmd = new SqlCommand("EditStudent", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@StudentID", id);
                    cmd.Parameters.AddWithValue("@Name", txtSName.Text);
                    cmd.Parameters.AddWithValue("@Gender", txtGender.Text);
                    cmd.Parameters.AddWithValue("@Semester", int.Parse(txtSem.Text));
                    cmd.Parameters.AddWithValue("@Section", txtSection.Text);
                    cmd.Parameters.AddWithValue("@CGPA", decimal.Parse(txtCGPA.Text));

                    cmd.ExecuteNonQuery();
                }

                // 2️⃣ Enroll (single course)
                if (!string.IsNullOrEmpty(txtCourseCode.Text))
                {
                    using (SqlCommand cmd2 = new SqlCommand("EditStudentEnrollment", con))
                    {
                        cmd2.CommandType = CommandType.StoredProcedure;

                        cmd2.Parameters.AddWithValue("@StudentID", id);
                        cmd2.Parameters.AddWithValue("@CourseCode", txtCourseCode.Text);

                        using (SqlDataReader reader = cmd2.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string message = reader["Message"].ToString();
                                MessageBox.Show(message);
                            }
                        }
                    }
                }

                MessageBox.Show("Student Updated Successfully");
                ClearFields();
            }
        }
    }
    

}
