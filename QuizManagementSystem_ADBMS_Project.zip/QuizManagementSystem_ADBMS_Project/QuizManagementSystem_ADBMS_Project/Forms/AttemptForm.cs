﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class AttemptForm : Form
    {
        int quizID, studentID;
        public AttemptForm(int qid, int sid)
        {
            InitializeComponent();
            quizID = qid;
            studentID = sid;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            ViewQuizzezFormStudent vqfs = new ViewQuizzezFormStudent(studentID);
            vqfs.Show();
            this.Hide();


        }

        private void btnSelectQuiz_Click(object sender, EventArgs e)
        {
            SolveQuizForm sqf = new SolveQuizForm(quizID,studentID);
            sqf.Show();
            this.Hide();
        }
    }
}
