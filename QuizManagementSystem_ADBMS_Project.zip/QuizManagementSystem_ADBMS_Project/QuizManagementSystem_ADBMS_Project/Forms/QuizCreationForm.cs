﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class QuizCreationForm : Form
    {
        /*  public QuizCreationForm()
          {
              InitializeComponent();
          }*/

        private int teacherID;

        public QuizCreationForm(int id)
        {
            InitializeComponent();
            teacherID = id;
        }


        private bool QuizExists(string courseCode)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Quiz WHERE CourseCode = @c", con))
            {
                cmd.Parameters.AddWithValue("@c", courseCode);

                con.Open();
                int count = (int)cmd.ExecuteScalar();

                return count > 0;
            }
        }

        private int CreateQuiz(string courseCode, int quizNumber, string title, int totalQuestions)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("CreateQuiz", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CourseCode", courseCode);
                cmd.Parameters.AddWithValue("@QuizNumber", quizNumber);
                cmd.Parameters.AddWithValue("@Title", title);
                cmd.Parameters.AddWithValue("@TotalQuestions", totalQuestions);

                con.Open();

                int newQuizID = Convert.ToInt32(cmd.ExecuteScalar());

                return newQuizID;
            }
        }
        private void btnStartQuizCreation_Click(object sender, EventArgs e)
        {
            
            string courseCode = cmbCourses.SelectedValue?.ToString();

            if (string.IsNullOrEmpty(courseCode))
            {
                MessageBox.Show("Please select a course.");
                return;
            }


            int qNo = int.Parse(txtQuizNumber.Text);

            int quizID = CreateQuiz(
                courseCode,
                qNo,
                txtQuizTitle.Text,
                int.Parse(txtTQNo.Text)
            );

            MessageBox.Show("Quiz created. ID = " + quizID);
            ClearFields();

            AddNewQuestionForm anqf = new AddNewQuestionForm(courseCode,txtQuizNumber.Text,teacherID);
            anqf.Show();
            this.Hide();
        }

        private void ClearFields()
        {
            //txtCourseCode.Clear();
            txtQuizNumber.Clear();
            txtTQNo.Clear();
            txtQuizTitle.Clear();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            QuizManagement qm = new QuizManagement(teacherID);
            qm.Show();
            this.Hide();
        }






        private void LoadTeacherCourses(int teacherID)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            using (SqlCommand cmd = new SqlCommand("GetTeacherCourses", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TeacherID", teacherID);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);

                cmbCourses.DataSource = dt;
                cmbCourses.DisplayMember = "CourseName";
                cmbCourses.ValueMember = "CourseCode";
            }

            if (cmbCourses.Items.Count == 0)
            {
                MessageBox.Show("No courses assigned to this teacher.");
            }
        }

        private void QuizCreationForm_Load(object sender, EventArgs e)
        {
            LoadTeacherCourses(teacherID);

        }

        private void cmbCourses_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

}
