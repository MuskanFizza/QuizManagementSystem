﻿using QuizManagementSystem_ADBMS_Project.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Forms
{
    public partial class ViewStudents : Form
    {
        public ViewStudents()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form previous = new StudentManagement();
            previous.Show();

        }
        private void btnView_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = DatabaseHelper.GetConnection())
            {
                using (SqlCommand cmd = new SqlCommand("GetStudents", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (cmbSearchBy.SelectedIndex == -1 || string.IsNullOrWhiteSpace(txtSearchValue.Text))
                    {
                        cmd.Parameters.AddWithValue("@SearchBy", DBNull.Value);
                        cmd.Parameters.AddWithValue("@SearchValue", DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@SearchBy", cmbSearchBy.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@SearchValue", txtSearchValue.Text.Trim());
                    }

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    con.Open();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = dt;
                    }
                    else
                    {
                        dataGridView1.DataSource = null;
                        MessageBox.Show("No record found or invalid search value.",
                                        "Search Result",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }
    }
}
