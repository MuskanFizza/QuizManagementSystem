﻿namespace QuizManagementSystem_ADBMS_Project.Forms
{
    partial class StudentManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.btnAddStd = new System.Windows.Forms.Button();
            this.btnViewStds = new System.Windows.Forms.Button();
            this.btnEditStd = new System.Windows.Forms.Button();
            this.btbDelStd = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(264, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(254, 23);
            this.label4.TabIndex = 17;
            this.label4.Text = "STUDENT MANAGEMENT";
            // 
            // btnAddStd
            // 
            this.btnAddStd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStd.Location = new System.Drawing.Point(202, 191);
            this.btnAddStd.Name = "btnAddStd";
            this.btnAddStd.Size = new System.Drawing.Size(146, 48);
            this.btnAddStd.TabIndex = 19;
            this.btnAddStd.Text = "Add Student";
            this.btnAddStd.UseVisualStyleBackColor = true;
            this.btnAddStd.Click += new System.EventHandler(this.btnAddStd_Click);
            // 
            // btnViewStds
            // 
            this.btnViewStds.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewStds.Location = new System.Drawing.Point(405, 191);
            this.btnViewStds.Name = "btnViewStds";
            this.btnViewStds.Size = new System.Drawing.Size(146, 48);
            this.btnViewStds.TabIndex = 20;
            this.btnViewStds.Text = "View Students";
            this.btnViewStds.UseVisualStyleBackColor = true;
            this.btnViewStds.Click += new System.EventHandler(this.btnViewStds_Click);
            // 
            // btnEditStd
            // 
            this.btnEditStd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditStd.Location = new System.Drawing.Point(202, 280);
            this.btnEditStd.Name = "btnEditStd";
            this.btnEditStd.Size = new System.Drawing.Size(146, 48);
            this.btnEditStd.TabIndex = 21;
            this.btnEditStd.Text = "Edit Student";
            this.btnEditStd.UseVisualStyleBackColor = true;
            this.btnEditStd.Click += new System.EventHandler(this.btnEditStd_Click);
            // 
            // btbDelStd
            // 
            this.btbDelStd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btbDelStd.Location = new System.Drawing.Point(405, 280);
            this.btbDelStd.Name = "btbDelStd";
            this.btbDelStd.Size = new System.Drawing.Size(146, 48);
            this.btbDelStd.TabIndex = 22;
            this.btbDelStd.Text = "Delete Student";
            this.btbDelStd.UseVisualStyleBackColor = true;
            this.btbDelStd.Click += new System.EventHandler(this.btbDelStd_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(318, 374);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(116, 35);
            this.btnBack.TabIndex = 23;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(177, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 31);
            this.label1.TabIndex = 24;
            this.label1.Text = "QUIZ MANAGEMENT SYSTEM";
            // 
            // StudentManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btbDelStd);
            this.Controls.Add(this.btnEditStd);
            this.Controls.Add(this.btnViewStds);
            this.Controls.Add(this.btnAddStd);
            this.Controls.Add(this.label4);
            this.Name = "StudentManagement";
            this.Text = "StudentManagement";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddStd;
        private System.Windows.Forms.Button btnViewStds;
        private System.Windows.Forms.Button btnEditStd;
        private System.Windows.Forms.Button btbDelStd;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label1;
    }
}