﻿namespace QuizManagementSystem_ADBMS_Project.Forms
{
    partial class ViewQuestionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.C1Ccode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C2question = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C2QID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.C3QTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSearch = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(376, 388);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(116, 35);
            this.btnBack.TabIndex = 32;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(337, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(174, 23);
            this.label4.TabIndex = 31;
            this.label4.Text = "QUESTIONS LIST";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(236, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 31);
            this.label1.TabIndex = 30;
            this.label1.Text = "QUIZ MANAGEMENT SYSTEM";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.C1Ccode,
            this.C2question,
            this.C2QID,
            this.C3QTitle});
            this.dataGridView1.Location = new System.Drawing.Point(148, 217);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(545, 140);
            this.dataGridView1.TabIndex = 29;
            // 
            // C1Ccode
            // 
            this.C1Ccode.Frozen = true;
            this.C1Ccode.HeaderText = "Course Code";
            this.C1Ccode.MinimumWidth = 6;
            this.C1Ccode.Name = "C1Ccode";
            this.C1Ccode.Width = 125;
            // 
            // C2question
            // 
            this.C2question.Frozen = true;
            this.C2question.HeaderText = "Quiz Title";
            this.C2question.MinimumWidth = 6;
            this.C2question.Name = "C2question";
            this.C2question.Width = 125;
            // 
            // C2QID
            // 
            this.C2QID.Frozen = true;
            this.C2QID.HeaderText = "Q ID";
            this.C2QID.MinimumWidth = 6;
            this.C2QID.Name = "C2QID";
            this.C2QID.Width = 125;
            // 
            // C3QTitle
            // 
            this.C3QTitle.Frozen = true;
            this.C3QTitle.HeaderText = "Question Title";
            this.C3QTitle.MinimumWidth = 6;
            this.C3QTitle.Name = "C3QTitle";
            this.C3QTitle.Width = 125;
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(287, 170);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(83, 19);
            this.lblSearch.TabIndex = 40;
            this.lblSearch.Text = "Search By:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "All",
            "TID",
            "TName",
            "Course"});
            this.comboBox1.Location = new System.Drawing.Point(376, 169);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(154, 24);
            this.comboBox1.TabIndex = 39;
            // 
            // ViewQuestionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "ViewQuestionsForm";
            this.Text = "ViewQuestionListForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn C1Ccode;
        private System.Windows.Forms.DataGridViewTextBoxColumn C2question;
        private System.Windows.Forms.DataGridViewTextBoxColumn C2QID;
        private System.Windows.Forms.DataGridViewTextBoxColumn C3QTitle;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}