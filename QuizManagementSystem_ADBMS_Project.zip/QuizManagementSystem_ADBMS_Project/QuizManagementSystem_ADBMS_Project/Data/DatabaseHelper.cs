﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuizManagementSystem_ADBMS_Project.Data
{
    internal class DatabaseHelper
    {
            // 🔴 CHANGE THIS
            private static string connectionString =
                @"Data Source=GILL;Initial Catalog=QuizManagementSystem;Integrated Security=True";

            public static SqlConnection GetConnection()
            {
                return new SqlConnection(connectionString);
            }

            public static bool TestConnection()
            {
                using (SqlConnection con = GetConnection())
                {
                    try
                    {
                       // con.Open();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Database connection failed!\n" + ex.Message);
                        return false;
                    }
                }
            }
        
    }
}
