CREATE DATABASE QuizManagementSystem;
--drop database QuizManagementSystem
USE QuizManagementSystem;

CREATE TABLE Roles (
    RoleID INT PRIMARY KEY IDENTITY,
    RoleName VARCHAR(20) UNIQUE NOT NULL
);

-- INSERT INTO Roles (RoleName) VALUES ('Admin'), ('Teacher'), ('Student');
-- select * from roles


CREATE TABLE Admins(
	AdminID INT PRIMARY KEY IDENTITY,
	AEmail VARCHAR(100) UNIQUE NOT NULL,
    APassword VARCHAR(100) NOT NULL,
    RoleID INT FOREIGN KEY REFERENCES Roles(RoleID)
)

CREATE TABLE Department (
    DepartmentID INT PRIMARY KEY IDENTITY,
    DepartmentName VARCHAR(100) UNIQUE NOT NULL
);


CREATE TABLE Teacher (
    TeacherID INT PRIMARY KEY IDENTITY,
    TName VARCHAR(100) NOT NULL,
    TDepartment VARCHAR(100) NOT NULL,
	DepartmentID INT FOREIGN KEY REFERENCES Department(DepartmentID),
    TEmail VARCHAR(100) UNIQUE NOT NULL,
    TPassword VARCHAR(100) NOT NULL,
    RoleID INT FOREIGN KEY REFERENCES Roles(RoleID)
);




CREATE TABLE Student (
    StudentID INT PRIMARY KEY IDENTITY,
    SName VARCHAR(100) NOT NULL,
	SGender VARCHAR(10) NOT NULL,
    Semester INT CHECK (Semester BETWEEN 1 AND 8),
	Section VARCHAR(10) NOT NULL,
    CGPA DECIMAL(3,2) CHECK (CGPA BETWEEN 0 AND 4),
    SEmail VARCHAR(100) UNIQUE NOT NULL,
    SPassword VARCHAR(100) NOT NULL,
    RoleID INT FOREIGN KEY REFERENCES Roles(RoleID)
);

select * from student
CREATE TABLE Course (
    CourseCode VARCHAR(10) PRIMARY KEY,
    CourseName VARCHAR(100) NOT NULL,
);

--EXEC sp_help 'Course';

select * from course

--ALTER TABLE Course DROP CONSTRAINT FK__Course__TeacherI__619B8048;  -- use your actual constraint name


CREATE TABLE CourseTeacher (
    CourseCode VARCHAR(10),
    TeacherID INT,
    PRIMARY KEY (CourseCode, TeacherID),
    FOREIGN KEY (CourseCode) REFERENCES Course(CourseCode),
    FOREIGN KEY (TeacherID) REFERENCES Teacher(TeacherID)
);

SELECT * FROM CourseTeacher

INSERT INTO Course VALUES
('CS101', 'Programming Fundamentals')

EXEC SP_HELP 'ENROLLMENT'

CREATE TABLE Enrollment (
    EnrollmentID INT PRIMARY KEY IDENTITY,
    StudentID INT FOREIGN KEY REFERENCES Student(StudentID),
    CourseCode VARCHAR(10) FOREIGN KEY REFERENCES Course(CourseCode),
	CONSTRAINT UQ_Student_Course UNIQUE (StudentID, CourseCode)

);


CREATE TABLE Quiz (
    QuizID INT PRIMARY KEY IDENTITY,
    CourseCode VARCHAR(10) FOREIGN KEY REFERENCES Course(CourseCode),
    QuizNumber INT NOT NULL,
    Title VARCHAR(100),
    TotalQuestions INT CHECK (TotalQuestions > 0),
	AssignedDate DATETIME DEFAULT GETDATE()

);

-- select * from quiz

CREATE TABLE Question (
    QuestionID INT PRIMARY KEY IDENTITY,
    QuizID INT FOREIGN KEY REFERENCES Quiz(QuizID),
    QuestionText VARCHAR(255) NOT NULL,
    Option1 VARCHAR(100) NOT NULL,
    Option2 VARCHAR(100) NOT NULL,
    Option3 VARCHAR(100) NOT NULL,
    Option4 VARCHAR(100) NOT NULL,
    CorrectOption INT CHECK (CorrectOption BETWEEN 1 AND 4) NOT NULL,
    Marks INT DEFAULT 1 CHECK (Marks > 0),

);


-- select * from Question


CREATE TABLE StudentQuiz (
    AttemptID INT PRIMARY KEY IDENTITY,
    StudentID INT FOREIGN KEY REFERENCES Student(StudentID),
    QuizID INT FOREIGN KEY REFERENCES Quiz(QuizID),
    MarksObtained INT DEFAULT 0,
    AttemptDate DATETIME DEFAULT GETDATE()
);


CREATE TABLE StudentAnswer (
    AnswerID INT PRIMARY KEY IDENTITY,
    AttemptID INT FOREIGN KEY REFERENCES StudentQuiz(AttemptID),
    QuestionID INT FOREIGN KEY REFERENCES Question(QuestionID),
    SelectedOption INT,
    IsCorrect BIT
);

select * from StudentAnswer
SELECT * FROM StudentQuiz

CREATE TABLE Result (
    ResultID INT PRIMARY KEY IDENTITY,
    StudentID INT,
    QuizID INT,
    TotalMarks INT,
    FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
    FOREIGN KEY (QuizID) REFERENCES Quiz(QuizID)
);

SELECT * FROM StudentQuiz
SELECT * FROM StudentAnswer
select * from Student


go;

ALTER PROCEDURE AddStudent
    @AdminID INT,
    @Name VARCHAR(100),
    @Gender VARCHAR(10),
    @Semester INT,
    @Section VARCHAR(10),
    @CGPA DECIMAL(3,2)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Admins WHERE AdminID = @AdminID)
    BEGIN
        PRINT 'Only admin allowed';
        RETURN;
    END

    DECLARE @cleanName VARCHAR(100);
    DECLARE @id INT;
    DECLARE @email VARCHAR(100);
    DECLARE @password VARCHAR(100);

    SET @cleanName = LOWER(REPLACE(@Name, ' ', ''));

    INSERT INTO Student (SName, SGender, Semester, Section, CGPA, SEmail, SPassword, RoleID)
    VALUES (@Name, @Gender, @Semester, @Section, @CGPA, 'temp@temp.com', 'temp', 3);

    SET @id = SCOPE_IDENTITY();

    SET @email = @cleanName + CAST(@id AS VARCHAR) + '@uni.com';
    SET @password = @cleanName + CAST(@id AS VARCHAR);

    UPDATE Student
    SET SEmail = @email,
        SPassword = @password
    WHERE StudentID = @id;

	SELECT @id AS StudentID;

    PRINT 'Student added successfully';
END;

go;

ALTER PROCEDURE EditStudent
    @StudentID INT,
    @Name VARCHAR(100),
    @Gender VARCHAR(10),
    @Semester INT,
    @Section VARCHAR(10),
    @CGPA DECIMAL(3,2)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Student WHERE StudentID = @StudentID)
    BEGIN
        PRINT 'Student not found';
        RETURN;
    END

    DECLARE @cleanName VARCHAR(100);
    DECLARE @email VARCHAR(100);
    DECLARE @password VARCHAR(100);

    -- Clean name
    SET @cleanName = LOWER(REPLACE(@Name, ' ', ''));

    SET @email = @cleanName + CAST(@StudentID AS VARCHAR) + '@uni.com';
    SET @password = @cleanName + CAST(@StudentID AS VARCHAR);

    UPDATE Student
    SET 
        SName = @Name,
        SGender = @Gender,
        Semester = @Semester,
        Section = @Section,
        CGPA = @CGPA,
        SEmail = @email,
        SPassword = @password
    WHERE StudentID = @StudentID;

    PRINT 'Student updated successfully';
END;


GO



CREATE PROCEDURE DeleteStudent
    @StudentID INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Student WHERE StudentID=@StudentID)
    BEGIN
        PRINT 'Student not found';
        RETURN;
    END

    BEGIN TRANSACTION;

    BEGIN TRY

        DELETE SA
        FROM StudentAnswer SA
        JOIN StudentQuiz SQ ON SA.AttemptID = SQ.AttemptID
        WHERE SQ.StudentID = @StudentID;

        DELETE FROM StudentQuiz WHERE StudentID=@StudentID;

        DELETE FROM Enrollment WHERE StudentID=@StudentID;

        DELETE FROM Student WHERE StudentID=@StudentID;

        COMMIT;
        PRINT 'Student deleted successfully';

    END TRY
    BEGIN CATCH
        ROLLBACK;
        PRINT 'Error deleting student';
    END CATCH
END;


GO


/*
CREATE PROCEDURE GetStudents
    @SearchBy VARCHAR(50) = NULL, -- 'ID', 'Name', 'Semester', 'CGPA'
    @SearchValue VARCHAR(100) = NULL
AS
BEGIN
    SELECT 
        StudentID AS [ID],
        SName AS [Name],
        Semester AS [Semester],
        CGPA AS [CGPA],
        SEmail AS [Email],
        SPassword AS [Password]
    FROM Student
    WHERE 
        (@SearchBy IS NULL) OR
    --    (@SearchBy = 'ID' AND CAST(StudentID AS VARCHAR) LIKE '%' + @SearchValue + '%') OR
	    (@SearchBy = 'ID' AND StudentID = @SearchValue) OR

        (@SearchBy = 'Name' AND SName LIKE '%' + @SearchValue + '%') OR
        (@SearchBy = 'Semester' AND CAST(Semester AS VARCHAR) = @SearchValue) OR
        (@SearchBy = 'CGPA' AND CAST(CGPA AS VARCHAR) LIKE @SearchValue + '%');
END;*/


ALTER PROCEDURE GetStudents
    @SearchBy VARCHAR(50) = NULL,
    @SearchValue VARCHAR(100) = NULL
AS
BEGIN
    SELECT 
        StudentID AS [ID],
        SName AS [Name],
        Semester AS [Semester],
        CGPA AS [CGPA],
        SEmail AS [Email],
        SPassword AS [Password]
    FROM Student
    WHERE 
        (@SearchBy IS NULL AND @SearchValue IS NULL) OR
        (@SearchBy = 'ID' AND CAST(@SearchValue AS INT) = StudentID) OR
        (@SearchBy = 'Name' AND SName LIKE '%' + @SearchValue + '%') OR
        (@SearchBy = 'Semester' AND CAST(@SearchValue AS INT) = Semester) OR
        (@SearchBy = 'CGPA' AND CAST(CGPA AS VARCHAR) = @SearchValue);
END;


GO



ALTER PROCEDURE AddTeacher
    @AdminID INT,
    @Name VARCHAR(100),
    @TDept VARCHAR(100),
    @DeptID INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Admins WHERE AdminID = @AdminID)
    BEGIN
        PRINT 'Only admin allowed';
        RETURN;
    END

    DECLARE @cleanName VARCHAR(100);
    DECLARE @id INT;
    DECLARE @email VARCHAR(100);
    DECLARE @password VARCHAR(100);

    SET @cleanName = LOWER(REPLACE(@Name, ' ', ''));

    -- STEP 1: Insert dummy values (IMPORTANT FIX)
    INSERT INTO Teacher (TName, TDepartment, DepartmentID, TEmail, TPassword, RoleID)
    VALUES (@Name, @TDept, @DeptID, 'temp@temp.com', 'temp', 2);

    SET @id = SCOPE_IDENTITY();

    -- STEP 2: Generate credentials
    SET @email = @cleanName + CAST(@id AS VARCHAR) + '@uni.com';
    SET @password = @cleanName + CAST(@id AS VARCHAR);

    -- STEP 3: Update actual values
    UPDATE Teacher
    SET TEmail = @email,
        TPassword = @password
    WHERE TeacherID = @id;

	SELECT @id AS TeacherID;

    PRINT 'Teacher added successfully';
END;


go;
EXEC AddTeacher 1, 'Sara Khan', 'Software Engineering', 2;
EXEC AddTeacher 1, 'Amir Khan', 'Software Engineering', 2;

select * from Teacher

ALTER PROCEDURE EditTeacher
    @TeacherID INT,
    @Name VARCHAR(100),
    @DeptID INT
AS
BEGIN
    DECLARE @cleanName VARCHAR(100);
    DECLARE @email VARCHAR(100);
    DECLARE @password VARCHAR(100);
    DECLARE @DepartmentName VARCHAR(100);

    IF NOT EXISTS (SELECT 1 FROM Teacher WHERE TeacherID= @TeacherID)
    BEGIN
        PRINT 'Teacher not found';
        RETURN;
    END

    SET @cleanName = LOWER(REPLACE(@Name, ' ', ''));

    SELECT @DepartmentName = DepartmentName
    FROM Department 
    WHERE DepartmentID = @DeptID;

    SET @email = @cleanName + CAST(@TeacherID AS VARCHAR) + '@uni.com';
    SET @password = @cleanName + CAST(@TeacherID AS VARCHAR);

    UPDATE Teacher
    SET TName = @Name,
        DepartmentID = @DeptID,
        TDepartment = @DepartmentName,
        TEmail = @email,
        TPassword = @password
    WHERE TeacherID = @TeacherID;

    PRINT 'Teacher updated successfully';
END;

EXEC EditTeacher 13, 'Sara Khan', 2, 'SE';

GO;



ALTER PROCEDURE DeleteTeacher
    @TeacherID INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Teacher WHERE TeacherID=@TeacherID)
    BEGIN
        PRINT 'Teacher not found';
        RETURN;
    END

    IF EXISTS (SELECT 1 FROM CourseTeacher WHERE TeacherID=@TeacherID)
    BEGIN
        PRINT 'Cannot delete teacher. Courses are assigned.';
        RETURN;
    END

    DELETE FROM Teacher WHERE TeacherID=@TeacherID;

    PRINT 'Teacher deleted successfully';
END;

EXEC DeleteTeacher 13
GO


/*
CREATE PROCEDURE GetTeachers
    @SearchBy VARCHAR(50) = NULL, -- 'ID', 'Name', 'Department', 'Course'
    @SearchValue VARCHAR(100) = NULL
AS
BEGIN
    SELECT 
        T.TeacherID AS [ID],
        T.TName AS [Name],
        D.DepartmentName AS [Department],
        C.CourseName AS [Course],
        T.TEmail AS [Email],
        T.TPassword AS [Password]
    FROM Teacher T
    LEFT JOIN Department D ON T.DepartmentID = D.DepartmentID
    LEFT JOIN Course C ON T.TeacherID = C.TeacherID
    WHERE 
        (@SearchBy IS NULL) OR
        (@SearchBy = 'ID' AND CAST(T.TeacherID AS VARCHAR) LIKE '%' + @SearchValue + '%') OR
        (@SearchBy = 'Name' AND T.TName LIKE '%' + @SearchValue + '%') OR
        (@SearchBy = 'Department' AND D.DepartmentName LIKE '%' + @SearchValue + '%') OR
        (@SearchBy = 'Course' AND C.CourseName LIKE '%' + @SearchValue + '%');
END;*/

ALTER PROCEDURE GetTeachers
    @SearchBy VARCHAR(50) = NULL,
    @SearchValue VARCHAR(100) = NULL
AS
BEGIN
    SELECT 
        T.TeacherID AS [ID],
        T.TName AS [Name],
        D.DepartmentName AS [Department],
        C.CourseName AS [Course],
        T.TEmail AS [Email],
        T.TPassword AS [Password]
    FROM Teacher T
    LEFT JOIN Department D ON T.DepartmentID = D.DepartmentID
    LEFT JOIN CourseTeacher CT ON T.TeacherID = CT.TeacherID
    LEFT JOIN Course C ON CT.CourseCode = C.CourseCode
    WHERE 
        (@SearchBy IS NULL AND @SearchValue IS NULL) OR
        (@SearchBy = 'ID' AND TRY_CAST(@SearchValue AS INT) = T.TeacherID) OR
        (@SearchBy = 'Name' AND T.TName LIKE '%' + @SearchValue + '%') OR
        (@SearchBy = 'Department' AND D.DepartmentName LIKE '%' + @SearchValue + '%') OR
        (@SearchBy = 'Course' AND C.CourseName LIKE '%' + @SearchValue + '%');
END;


GO
EXEC GetTeachers 'ID', '12'
EXEC GetTeachers 'ID', '14'
select * from Teacher



CREATE PROCEDURE CreateQuiz
    @CourseCode VARCHAR(10),
    @QuizNumber INT,
    @Title VARCHAR(100),
    @TotalQuestions INT
AS
BEGIN
    INSERT INTO Quiz (CourseCode, QuizNumber, Title, TotalQuestions)
    VALUES (@CourseCode, @QuizNumber, @Title, @TotalQuestions);
    SELECT SCOPE_IDENTITY() AS NewQuizID;
END;


GO
SELECT * FROM QUIZ

ALTER PROCEDURE AddQuestion
    @QuizID INT,
    @Text VARCHAR(255),
    @O1 VARCHAR(100), @O2 VARCHAR(100),
    @O3 VARCHAR(100), @O4 VARCHAR(100),
    @Correct INT,
    @Marks INT
AS
BEGIN
    DECLARE @CurrentCount INT;
    DECLARE @MaxQuestions INT;

    SELECT @CurrentCount = COUNT(*) FROM Question WHERE QuizID = @QuizID;
    SELECT @MaxQuestions = TotalQuestions FROM Quiz WHERE QuizID = @QuizID;

    IF @MaxQuestions IS NULL
    BEGIN
        SELECT 'Invalid QuizID' AS Message;
        RETURN;
    END

    IF @CurrentCount >= @MaxQuestions
    BEGIN
        SELECT 'Question limit reached' AS Message;
        RETURN;
    END

    INSERT INTO Question
    VALUES (@QuizID,@Text,@O1,@O2,@O3,@O4,@Correct,@Marks);

    SELECT 'Question added successfully' AS Message;
END;
select * from Question
select * from quiz
GO




CREATE PROCEDURE EditQuestion
    @QuestionID INT,
    @QuestionText VARCHAR(255),
    @Opt1 VARCHAR(100),
    @Opt2 VARCHAR(100),
    @Opt3 VARCHAR(100),
    @Opt4 VARCHAR(100),
    @CorrectOption INT,
    @Marks INT
AS
BEGIN
    DECLARE @QuizID INT;
    DECLARE @AttemptCount INT;

    IF NOT EXISTS (SELECT 1 FROM Question WHERE QuestionID = @QuestionID)
    BEGIN
        PRINT 'Question not found';
        RETURN;
    END

    SELECT @QuizID = QuizID FROM Question WHERE QuestionID = @QuestionID;

    SELECT @AttemptCount = COUNT(*) FROM StudentQuiz WHERE QuizID = @QuizID;

    IF @AttemptCount > 0
    BEGIN
        PRINT 'Cannot edit question: Quiz already attempted';
        RETURN;
    END

    IF @CorrectOption NOT BETWEEN 1 AND 4
    BEGIN
        PRINT 'Correct option must be between 1 and 4';
        RETURN;
    END

    UPDATE Question
    SET QuestionText = @QuestionText,
        Option1 = @Opt1, Option2 = @Opt2,
        Option3 = @Opt3, Option4 = @Opt4,
        CorrectOption = @CorrectOption,
        Marks = @Marks
    WHERE QuestionID = @QuestionID;

    PRINT 'Question updated successfully';
END;


GO

ALTER PROCEDURE DeleteQuestion
    @QuestionID INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if question exists
    IF NOT EXISTS (SELECT 1 FROM Question WHERE QuestionID = @QuestionID)
    BEGIN
        SELECT 'Question not found' AS Message;
        RETURN;
    END

    BEGIN TRANSACTION;
    BEGIN TRY
        DELETE FROM StudentAnswer WHERE QuestionID = @QuestionID;
        DELETE FROM Question WHERE QuestionID = @QuestionID;

        COMMIT TRANSACTION;

        SELECT 'Question deleted successfully' AS Message;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        SELECT 'Error deleting question' AS Message;
    END CATCH
END;

GO


ALTER PROCEDURE DeleteEntireQuizForceful
    @QuizID INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM Quiz WHERE QuizID = @QuizID)
    BEGIN
        SELECT 'Quiz not found' AS Message;
        RETURN;
    END

    BEGIN TRANSACTION;
    BEGIN TRY
        DELETE SA
        FROM StudentAnswer SA
        INNER JOIN StudentQuiz SQ ON SA.AttemptID = SQ.AttemptID
        WHERE SQ.QuizID = @QuizID;

        DELETE FROM StudentQuiz WHERE QuizID = @QuizID;
        DELETE FROM Result WHERE QuizID = @QuizID;
        DELETE FROM Question WHERE QuizID = @QuizID;
        DELETE FROM Quiz WHERE QuizID = @QuizID;

        COMMIT TRANSACTION;

        SELECT 'Quiz deleted successfully' AS Message;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        SELECT 'Error deleting quiz' AS Message;
    END CATCH
END;

GO



CREATE PROCEDURE StartQuizAttempt
    @StudentID INT,
    @QuizID INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM StudentQuiz WHERE StudentID=@StudentID AND QuizID=@QuizID)
    BEGIN
        PRINT 'Already attempted';
        RETURN;
    END

    INSERT INTO StudentQuiz (StudentID,QuizID)
    VALUES (@StudentID,@QuizID);
END;


GO;



CREATE TRIGGER trg_UpdateMarks
ON StudentAnswer
AFTER INSERT
AS
BEGIN
    UPDATE SA
    SET IsCorrect = CASE 
        WHEN Q.CorrectOption = SA.SelectedOption THEN 1 ELSE 0 END
    FROM StudentAnswer SA
    JOIN inserted i ON SA.AnswerID = i.AnswerID
    JOIN Question Q ON i.QuestionID = Q.QuestionID;

    UPDATE SQ
    SET MarksObtained = SQ.MarksObtained + Q.Marks
    FROM StudentQuiz SQ
    JOIN inserted i ON SQ.AttemptID = i.AttemptID
    JOIN Question Q ON i.QuestionID = Q.QuestionID
    WHERE Q.CorrectOption = i.SelectedOption;
END;



go;


ALTER FUNCTION GetQuizResults 
(
    @StudentID INT = NULL,
    @StudentName VARCHAR(100) = NULL,
    @CourseCode VARCHAR(10) = NULL
)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        S.StudentID AS SID, 
        S.SName, 
        C.CourseCode, 
        Q.QuizNumber AS Quizzes,
        SQ.MarksObtained,
        Q.TotalQuestions
    FROM Student S
    JOIN StudentQuiz SQ ON S.StudentID = SQ.StudentID
    JOIN Quiz Q ON SQ.QuizID = Q.QuizID
    JOIN Course C ON Q.CourseCode = C.CourseCode
    WHERE 
        (@StudentID IS NULL OR S.StudentID = @StudentID)
        AND (@StudentName IS NULL OR S.SName LIKE '%' + @StudentName + '%')
        AND (@CourseCode IS NULL OR C.CourseCode = @CourseCode)
);


CREATE PROCEDURE GetStudentResults
AS
BEGIN
    SELECT 
        S.StudentID AS SID, 
        S.SName, 
        C.CourseCode, 
        Q.QuizNumber AS Quizes,
        SQ.MarksObtained
    FROM Student S
    JOIN StudentQuiz SQ ON S.StudentID = SQ.StudentID
    JOIN Quiz Q ON SQ.QuizID = Q.QuizID
    JOIN Course C ON Q.CourseCode = C.CourseCode;
END;

GO

EXEC GetStudentResults
SELECT * FROM GetQuizResults(6);


/*
ALTER PROCEDURE GetQuizDetails
    @SearchBy VARCHAR(50) = NULL, 
    @SearchValue VARCHAR(100) = NULL
AS
BEGIN
    SELECT 
        Q.CourseCode, 
        Q.Title AS QuizTitle, 
        QN.QuestionID AS QID, 
        QN.QuestionText AS QuestionTitle
    FROM Quiz Q
    JOIN Question QN ON Q.QuizID = QN.QuizID
    WHERE 
        (@SearchBy IS NULL) OR
        (@SearchBy = 'CourseCode' AND Q.CourseCode LIKE '%' + @SearchValue + '%') OR
        (@SearchBy = 'QuizTitle' AND Q.Title LIKE '%' + @SearchValue + '%') OR
        (@SearchBy = 'QuestionID' AND CAST(QN.QuestionID AS VARCHAR) = @SearchValue) OR
		(@SearchBy = 'QuizID' AND CAST(Q.QuizID AS VARCHAR) = @SearchValue) OR
        (@SearchBy = 'QuizNumber' AND CAST(Q.QuizNumber AS VARCHAR) = @SearchValue)


END;
*/



ALTER PROCEDURE GetQuizDetails
    @TeacherID INT,
    @SearchBy VARCHAR(50) = NULL, 
    @SearchValue VARCHAR(100) = NULL
AS
BEGIN
    SELECT 
        Q.QuizID,
        Q.CourseCode, 
        Q.Title AS QuizTitle, 
        Q.TotalQuestions,
        QN.QuestionID AS QID, 
        QN.QuestionText AS QuestionTitle
    FROM Quiz Q
    INNER JOIN CourseTeacher CT ON Q.CourseCode = CT.CourseCode
    LEFT JOIN Question QN ON Q.QuizID = QN.QuizID
    WHERE 
        CT.TeacherID = @TeacherID
        AND
        (
            @SearchBy IS NULL OR
            (@SearchBy = 'CourseCode' AND Q.CourseCode LIKE '%' + @SearchValue + '%') OR
            (@SearchBy = 'QuizTitle' AND Q.Title LIKE '%' + @SearchValue + '%') OR
			(@SearchBy = 'QuestionID' AND CAST(QN.QuestionID AS VARCHAR) = @SearchValue) OR
            (@SearchBy = 'QuizID' AND CAST(Q.QuizID AS VARCHAR) = @SearchValue) OR
            (@SearchBy = 'QuizNumber' AND CAST(Q.QuizNumber AS VARCHAR) = @SearchValue)
        );
END;
go;

SELECT * FROM QUIZ
exec GetQuizDetails 15, 'coursecode', 'AI402'
exec GetQuizDetails 17, 'QuizTitle', 'oop'


GO;





CREATE PROCEDURE GetQuizzesByCourse
    @TeacherID INT,
    @CourseCode VARCHAR(10)
AS
BEGIN
    SELECT 
        Q.QuizID,
        Q.CourseCode,
        Q.Title AS QuizTitle,
        Q.TotalQuestions,
		Q.AssignedDate
    FROM Quiz Q
    INNER JOIN Course C ON Q.CourseCode = C.CourseCode
    WHERE Q.CourseCode = @CourseCode
    AND C.TeacherID = @TeacherID;
END;




GO;



CREATE PROCEDURE GetStudentResults
AS
BEGIN
    SELECT 
        S.StudentID AS SID, 
        S.SName, 
        C.CourseCode, 
        Q.QuizNumber AS Quizes,
        SQ.MarksObtained
    FROM Student S
    JOIN StudentQuiz SQ ON S.StudentID = SQ.StudentID
    JOIN Quiz Q ON SQ.QuizID = Q.QuizID
    JOIN Course C ON Q.CourseCode = C.CourseCode;
END;

GO

SELECT * FROM StudentQuiz
SELECT * FROM StudentAnswer


CREATE PROCEDURE AuthenticateUser
    @Email VARCHAR(100),
    @Password VARCHAR(100),
    @RoleName VARCHAR(20)
AS
BEGIN
    IF @RoleName = 'Admin'
        SELECT AdminID AS UserID, RoleID FROM Admins WHERE AEmail = @Email AND APassword = @Password;
    ELSE IF @RoleName = 'Teacher'
        SELECT TeacherID AS UserID, RoleID FROM Teacher WHERE TEmail = @Email AND TPassword = @Password;
    ELSE IF @RoleName = 'Student'
        SELECT StudentID AS UserID, RoleID FROM Student WHERE SEmail = @Email AND SPassword = @Password;
END;


GO;


ALTER PROCEDURE AssignTeacherToCourse
    @TeacherID INT,
    @CourseCode VARCHAR(10),
    @CourseName VARCHAR(50)
AS
BEGIN
    -- Insert course if not exists
    IF NOT EXISTS (SELECT 1 FROM Course WHERE CourseCode = @CourseCode)
    BEGIN
        INSERT INTO Course (CourseCode, CourseName)
        VALUES (@CourseCode, @CourseName);
    END

    -- Assign teacher
    IF NOT EXISTS (
        SELECT 1 FROM CourseTeacher 
        WHERE CourseCode = @CourseCode AND TeacherID = @TeacherID
    )
    BEGIN
        INSERT INTO CourseTeacher VALUES (@CourseCode, @TeacherID);
    END

    PRINT 'Teacher assigned to course';
END;

EXEC AssignTeacherToCourse 14, 'SE201', 'Software Design'
EXEC AssignTeacherToCourse 14, 'SE201', 'Software Design'
EXEC AssignTeacherToCourse 21, 'AI402', 'Deep Learning';

select * from course

go;

ALTER PROCEDURE EditAssignTeacherToCourse
    @TeacherID INT,
    @CourseCode VARCHAR(10),
    @CourseName VARCHAR(50)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Course WHERE CourseCode = @CourseCode)
    BEGIN
        UPDATE Course
        SET CourseName = @CourseName
        WHERE CourseCode = @CourseCode;
    END
    ELSE
    BEGIN
        INSERT INTO Course (CourseCode, CourseName)
        VALUES (@CourseCode, @CourseName);
    END

    IF NOT EXISTS (
        SELECT 1 FROM CourseTeacher 
        WHERE CourseCode = @CourseCode AND TeacherID = @TeacherID
    )
    BEGIN
        INSERT INTO CourseTeacher VALUES (@CourseCode, @TeacherID);
    END

    PRINT 'Updated successfully';
END;

EXEC EditAssignTeacherToCourse 14, 'AI402', 'Deep Learning';
EXEC EditAssignTeacherToCourse 21, 'AI402', 'Deep Learning';



EXEC GetTeachers 'ID', '15'
EXEC GetTeachers 'ID', '14'

select * from Teacher
select * from Course
select * from student
select * from Enrollment

ALTER PROCEDURE EnrollStudentInCourse
    @StudentID INT,
    @CourseCode VARCHAR(10)
AS
BEGIN
    -- Ensure course exists
    IF NOT EXISTS (SELECT 1 FROM Course WHERE CourseCode = @CourseCode)
    BEGIN
        RAISERROR('Course does not exist', 16, 1);
        RETURN;
    END

    -- Enroll student if not already enrolled
    IF NOT EXISTS (
        SELECT 1 FROM Enrollment
        WHERE StudentID = @StudentID AND CourseCode = @CourseCode
    )
    BEGIN
        INSERT INTO Enrollment (StudentID, CourseCode)
        VALUES (@StudentID, @CourseCode);
    END

    PRINT 'Student enrolled in course';
END;


EXEC EnrollStudentInCourse 7, 'SE201'
EXEC EnrollStudentInCourse 8, 'AI402'
EXEC EnrollStudentInCourse 7, 'AI401'


select * from student
select * from Enrollment

EXEC GetStudents 'id', 6


ALTER PROCEDURE EditStudentEnrollment
    @StudentID INT,
    @CourseCode VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if already enrolled
    IF EXISTS (
        SELECT 1 FROM Enrollment 
        WHERE StudentID = @StudentID AND CourseCode = @CourseCode
    )
    BEGIN
        SELECT 0 AS Success, 'Student already enrolled in this course' AS Message;
        RETURN;
    END

    -- Insert enrollment
    INSERT INTO Enrollment (StudentID, CourseCode)
    VALUES (@StudentID, @CourseCode);

    SELECT 1 AS Success, 'Enrollment added successfully' AS Message;
END;

-- ===============================


select * from Admins
select * from roles
select * from Teacher
select * from student
select * from Enrollment
select * from Course
select * from CourseTeacher
select * from Quiz
select * from Question



INSERT INTO Roles (RoleName)
VALUES ('Admin'), ('Teacher'), ('Student');

INSERT INTO Admins (AEmail, APassword, RoleID)
VALUES ('admin@uni.com', 'admin123', 1);

select * from Admins
select * from Department

-- Departments
INSERT INTO Department (DepartmentName) VALUES
('Computer Science'),
('Software Engineering'),
('Information Technology'),
('Artificial Intelligence'),
('Cyber Security');


--EXEC AddTeacher 1, 'Ali Hassan', 'Computer Science', 1;
EXEC AddTeacher 1, 'Sara Khan', 'Software Engineering', 2;
EXEC AddTeacher 1, 'Ahmed Raza', 'Information Technology', 3;
EXEC AddTeacher 1, 'Fatima Noor', 'Artificial Intelligence', 4;
EXEC AddTeacher 1, 'Usman Tariq', 'Cyber Security', 5;

EXEC AddTeacher 1, 'Hina Malik', 'Computer Science', 1;
EXEC AddTeacher 1, 'Bilal Ahmed', 'Software Engineering', 2;
EXEC AddTeacher 1, 'Ayesha Khan', 'Information Technology', 3;
EXEC AddTeacher 1, 'Zain Ali', 'Artificial Intelligence', 4;
EXEC AddTeacher 1, 'Laiba Fatima', 'Cyber Security', 5;


INSERT INTO Course VALUES
('CS101', 'Programming Fundamentals'),
('CS102', 'Data Structures'),
('CS103', 'OOP'),
('CS104', 'Operating Systems'),
('SE201', 'Software Design'),
('SE202', 'Design Patterns'),
('IT301', 'Network Security'),
('IT302', 'Database Systems'),
('AI401', 'Machine Learning'),
('AI402', 'Deep Learning');

INSERT INTO COURSE VALUES ('IT302', 'Database Systems')
INSERT INTO COURSE VALUES ('CS102', 'Data Structures')
INSERT INTO COURSE VALUES ('CS104', 'Operating Systems')
INSERT INTO COURSE VALUES ('SE202', 'Design Patterns')




select * from Course

--EXEC AddStudent 1, 'John Smith', 'Male', 1, 'A', 3.2;
EXEC AddStudent 1, 'Emma Watson', 'Female', 2, 'B', 3.6;
EXEC AddStudent 1, 'David Miller', 'Male', 3, 'A', 2.9;
EXEC AddStudent 1, 'Sophia Brown', 'Female', 4, 'C', 3.8;
EXEC AddStudent 1, 'Michael Lee', 'Male', 1, 'A', 2.5;

EXEC AddStudent 1, 'Olivia Wilson', 'Female', 2, 'B', 3.1;
EXEC AddStudent 1, 'James Taylor', 'Male', 3, 'A', 3.4;
EXEC AddStudent 1, 'Isabella Davis', 'Female', 4, 'C', 3.9;
EXEC AddStudent 1, 'Ethan Clark', 'Male', 5, 'A', 2.7;
EXEC AddStudent 1, 'Mia Hall', 'Female', 6, 'B', 3.3;

EXEC AddStudent 1, 'Alexander Young', 'Male', 1, 'C', 2.8;
EXEC AddStudent 1, 'Charlotte King', 'Female', 2, 'A', 3.5;
EXEC AddStudent 1, 'Daniel Scott', 'Male', 3, 'B', 3.0;
EXEC AddStudent 1, 'Amelia Green', 'Female', 4, 'A', 3.7;
EXEC AddStudent 1, 'Henry Adams', 'Male', 5, 'C', 2.6;

EXEC AddStudent 1, 'Lily Baker', 'Female', 6, 'B', 3.8;
EXEC AddStudent 1, 'William Nelson', 'Male', 7, 'A', 3.2;
EXEC AddStudent 1, 'Grace Carter', 'Female', 8, 'C', 3.9;
EXEC AddStudent 1, 'Benjamin Perez', 'Male', 2, 'B', 2.9;
EXEC AddStudent 1, 'Chloe Roberts', 'Female', 3, 'A', 3.6;

select * from student


INSERT INTO Enrollment (StudentID, CourseCode) VALUES
--(6, 'CS101'),
(2, 'SE201'),
(3, 'IT301'),
(4, 'AI401'),
(5, 'CS102'),
(6, 'SE202'),
(7, 'IT302'),
(8, 'AI402'),
(9, 'CS103'),
(10, 'CS104');


-- EXEC CreateQuiz 'CS101', 1, 'Intro Quiz', 5;
EXEC CreateQuiz 'SE201', 1, 'Design Basics', 5;
EXEC CreateQuiz 'IT301', 1, 'Network Quiz', 5;
EXEC CreateQuiz 'AI401', 1, 'ML Basics', 5;
EXEC CreateQuiz 'CS102', 1, 'DS Quiz', 5;

SELECT *

-- EXEC AddQuestion 6, 'What is C++?', 'Language', 'OS', 'DB', 'Tool', 1, 1;

-- EXEC AddQuestion 6, 'OOP stands for?', 'Open','Object Oriented Programming', 'Order', 'Option', 2, 1;

-- EXEC AddQuestion 6, 'UML used for?', 'Music', 'Design', 'Math', 'None', 2, 1;

-- EXEC AddQuestion 6, 'IP stands for?', 'Internal Process', 'Input', 'Internet Protocol', 'None', 3, 1;

-- EXEC AddQuestion 6, 'ML is?', 'Machine Learning', 'Manual Logic', 'Math Layer', 'None', 1, 1;

select * from Question
select * from quiz

select * from Enrollment

EXEC StartQuizAttempt 1, 1;
EXEC StartQuizAttempt 2, 2;
EXEC StartQuizAttempt 3, 3;
EXEC StartQuizAttempt 4, 4;
EXEC StartQuizAttempt 5, 5;

INSERT INTO StudentAnswer (AttemptID, QuestionID, SelectedOption)
VALUES
(1, 1, 1),
(1, 2, 1),
(2, 3, 1),
(3, 4, 1);

INSERT INTO Result (StudentID, QuizID, TotalMarks)
VALUES (1, 1, 3);



-- ============================================================

ALTER PROCEDURE GetTeacherCourses
    @TeacherID INT
AS
BEGIN
    SELECT C.CourseCode, C.CourseName
    FROM Course C
    INNER JOIN CourseTeacher CT ON C.CourseCode = CT.CourseCode
    WHERE CT.TeacherID = @TeacherID;
END;

CREATE PROCEDURE GetStudentCourses
    @StudentID INT
AS
BEGIN
    SELECT DISTINCT C.CourseCode, C.CourseName
    FROM Course C
    INNER JOIN Enrollment E ON C.CourseCode = E.CourseCode
    WHERE E.StudentID = @StudentID;
END;


CREATE PROCEDURE CheckQuizExists
    @CourseCode VARCHAR(10)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Quiz WHERE CourseCode = @CourseCode)
        SELECT 1 AS QuizExists;
    ELSE
        SELECT 0 AS QuizExists;
END;



/*CREATE PROCEDURE GetQuizzesByTeacherCourse
    @TeacherID INT,
    @CourseCode VARCHAR(10)
AS
BEGIN
    SELECT QuizID, QuizNumber, Title, TotalQuestions, CourseCode
    FROM Quiz
    WHERE CourseCode = @CourseCode
    AND CourseCode IN (
        SELECT CourseCode FROM Course WHERE TeacherID = @TeacherID
    );
END;*/


ALTER PROCEDURE GetQuizzesByTeacherCourse
    @TeacherID INT,
    @CourseCode VARCHAR(10)
AS
BEGIN
    SELECT 
        Q.QuizID,
        Q.CourseCode,
        Q.Title AS QuizTitle,
        Q.TotalQuestions,
        Q.AssignedDate
    FROM Quiz Q
    INNER JOIN CourseTeacher CT ON Q.CourseCode = CT.CourseCode
    WHERE Q.CourseCode = @CourseCode
      AND CT.TeacherID = @TeacherID;
END;




CREATE PROCEDURE GetQuizzesByStudentCourse
    @StudentID INT,
    @CourseCode VARCHAR(10)
AS
BEGIN
    SELECT 
        Q.QuizID,
        Q.CourseCode,
        Q.Title AS QuizTitle,
        Q.TotalQuestions,
        Q.AssignedDate
    FROM Quiz Q
    INNER JOIN Enrollment E ON Q.CourseCode = E.CourseCode
    WHERE E.StudentID = @StudentID
      AND Q.CourseCode = @CourseCode;
END;


CREATE PROCEDURE GetQuizDetailsForStudent
    @StudentID INT,
    @SearchBy VARCHAR(50) = NULL, 
    @SearchValue VARCHAR(100) = NULL
AS
BEGIN
    SELECT 
        Q.QuizID,
        Q.CourseCode,
        Q.Title AS QuizTitle,
        QN.QuestionID,
        QN.QuestionText
    FROM Quiz Q
    INNER JOIN Enrollment E ON Q.CourseCode = E.CourseCode
    LEFT JOIN Question QN ON Q.QuizID = QN.QuizID
    WHERE 
        E.StudentID = @StudentID
        AND
        (
            @SearchBy IS NULL OR
            (@SearchBy = 'CourseCode' AND Q.CourseCode LIKE '%' + @SearchValue + '%') OR
            (@SearchBy = 'QuizTitle' AND Q.Title LIKE '%' + @SearchValue + '%') OR
            (@SearchBy = 'QuizID' AND CAST(Q.QuizID AS VARCHAR) = @SearchValue)
        )
END;




CREATE PROCEDURE CopyQuizQuestions
    @SourceQuizID INT,
    @TargetQuizID INT
AS
BEGIN
    SET NOCOUNT ON;

  
    IF NOT EXISTS (SELECT 1 FROM Quiz WHERE QuizID = @SourceQuizID)
    BEGIN
        SELECT 'Source quiz does not exist.' AS Message;
        RETURN;
    END


    IF NOT EXISTS (SELECT 1 FROM Quiz WHERE QuizID = @TargetQuizID)
    BEGIN
        SELECT 'Target quiz does not exist.' AS Message;
        RETURN;
    END

   
    IF NOT EXISTS (SELECT 1 FROM Question WHERE QuizID = @SourceQuizID)
    BEGIN
        SELECT 'No questions found in the source quiz.' AS Message;
        RETURN;
    END

 
    INSERT INTO Question 
    (QuizID, QuestionText, Option1, Option2, Option3, Option4, CorrectOption, Marks)
    SELECT 
        @TargetQuizID,
        QuestionText,
        Option1,
        Option2,
        Option3,
        Option4,
        CorrectOption,
        Marks
    FROM Question
    WHERE QuizID = @SourceQuizID;

    -- Update total questions
    UPDATE Quiz
    SET TotalQuestions = (
        SELECT COUNT(*) 
        FROM Question 
        WHERE QuizID = @TargetQuizID
    )
    WHERE QuizID = @TargetQuizID;

    SELECT 'Questions copied successfully and total count updated.' AS Message;
END;

select * from Quiz
select * from Question